import { Component, OnInit, Injectable, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupform: FormGroup;
  errormsg:any;
  private signupapi = this.getdata.appconstant + 'signUp';

  /** Final App Code */
  finalappcode: any;
  emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  numbervalidation = /^[0-9,/]+$/;
  alphanumeric = /^[a-zA-Z0-9]+$/;
  alphawithdot= /^[a-zA-Z. ]+$/;
   decimalnumber = /^(0|[1-9]\d*)(\.\d+)?$/;
  alpha = /^[a-zA-Z]+$/;
  passwordvalidation = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;
  phonevalidation = /^.{10,}$/;

  constructor(private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {
    this.signupform = Formbuilder.group({
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'password': [null, Validators.compose([Validators.required, Validators.pattern(this.passwordvalidation)])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.phonevalidation), Validators.minLength(10), Validators.maxLength(15)])],
      'type': ["organization", Validators.compose([Validators.required])],
      'name': [null, Validators.compose([Validators.required])],
      'appcode': [null, Validators.compose([Validators.required])],
    });
  }

  ngOnInit() {
  }
  orgtext: any = "Organization";
  getorgtype(e) {
    if (e.target.value == "organization") {
      this.orgtext = "Organization";
    } else {
      this.orgtext = "Client";
    }
  }
  signup() {
    // var tmp = this.signupform.value.email;
    // var tmp1 = tmp.split('@');
    // var tmp2 = tmp1.split('.');
    // console.log(tmp2[0]);
    // return false;    
    this.signupform.value.phone = this.signupform.value.phone.toString();

    let signupdata = 'signupobj=' + JSON.stringify(this.signupform.value);
    return this.makeapi.method(this.signupapi, signupdata, "post")
      .subscribe(data => {
        // if (data.status == "success") {
        //   localStorage.setItem("sevinvoicesession", JSON.stringify(data));
        //   this.router.navigateByUrl('/dashboard/home');

        // }
        if(data.isExists == true ){
          this.errormsg = 'Email already exists';
        }
        else if (data.status == "success" && data.type == "organization") { 
          localStorage.setItem("sevinvoicesession", JSON.stringify(data));
          this.router.navigateByUrl('/dashboard/home');

        }
        else if (data.status == "success" && data.type == "employee") { 
          localStorage.setItem("sevinvoicesession", JSON.stringify(data));
          this.router.navigateByUrl('/dashboard/invoice');

        }
        else if (data.status == "success" && data.type == "client") { 
          localStorage.setItem("sevinvoicesession", JSON.stringify(data));
          this.router.navigateByUrl('/dashboard/myinvoices');

        }
        else{
         this.errormsg = 'Something went wrong try again later';
          

        }
      },
        Error => {
          // alert( 'add stock error' );
        });
  }

  generateCode(event) {
    var getDate = event.target.value;
    var splitemail = getDate.split('@');
    var emailsplitbefore = splitemail[0];
    var emailsplitafter = splitemail[1].split(".").join("");
    this.finalappcode = emailsplitbefore + emailsplitafter;
    var getdata = this.signupform.value;
    getdata.appcode = this.finalappcode;
    this.signupform.patchValue(getdata);

  }
}
