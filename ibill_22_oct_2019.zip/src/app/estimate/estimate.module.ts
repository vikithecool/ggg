import { NgModule  } from '@angular/core';
import { routing } from "./estimate.routing";
import { EstimateComponent } from "./estimate.component";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { AbstractControl } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@NgModule({
  imports: [routing,FormsModule,ReactiveFormsModule,CommonModule,NgSelectModule,
    BsDatepickerModule.forRoot(), NgxPaginationModule],
  declarations: [EstimateComponent],
})
export class EstimateModule {}