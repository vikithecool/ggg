import { Component, OnInit, Pipe, PipeTransform, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { ViewestimatesComponent } from '../viewestimates/viewestimates.component';
import { AuthGuard } from '../canactivate.service';
import { modalvaluetesting } from '../modal.service';

declare var $;

@Component({
  selector: 'app-estimate',
  templateUrl: './estimate.component.html',
  styleUrls: ['./estimate.component.css']
})
export class EstimateComponent implements OnInit {

  /** Add New Row */
  productdetails: any;
  hsn: any;
  // description: any;
  price: any;
  discount: any;
  discounttype: "percentage";
  quantity: any;
  itemnumbererror: any;
  stockerror: any;
  descriptionerror: any;
  priceerror: any;
  discounterror: any;
  quantityerror: any;
  cgst: any;
  sgst: any;
  igst: any;

  /** Get Product Details */
  getProductdata: any;

  /** Get All Value On Selected Product */
  prod_total = [];


  /** Get Customer Data */
  getCustomerdata: any;

  /** Get Invoice From  Data */
  getCredentialsdata: any;

  /** Get All states */
  states: any;

  /** Get Sales Person Details */
  getSalesPerson: any;

  formattedMessage: any;


  /** Show Shipping details */
  getCustomerid: any;
  getShippingAddress: any;
  getShippingName: any;
  getShippingCity: any;
  getShippingState: any;
  getShippingCountry: any;
  getShippingzip: any;
  getShippingStreet: any;
  showSelected: any;

  /** Craeate Invoice */
  raiseInvoiceForm: FormGroup;
  // details: FormArray;

  /** Onchange Calcultaion */
  summed: number;

  /**  Check Place */
  check_place = '';

  /** Add Configurtaion */
  dueterms: string;

  /** Set todays date */
  today = Date.now();
  msg: any;

  /** GEt Payment Due terms */
  duetermsdata: any;
  bsValue = new Date();
  duedate: Date = new Date();

  /** Get Invoice Next Number */
  estimatenextnumber: any;

  /** Gert Shipping Address */
  dynamicshippingaddress: any;

  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;

  lastaddcust = false;
  @ViewChild("estimateform") estimateform: any;
  @ViewChild("ViewestimatesComponent") ViewestimatesComponent: Component;



  constructor(private modaldatatesting: modalvaluetesting, private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http, private ref: ChangeDetectorRef) {

    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
  }


  private getProducts = this.getdata.appconstant + 'getProducts';
  private getSingleProduct = this.getdata.appconstant + 'getProduct';
  private getCustomer = this.getdata.appconstant + 'getCustomer';
  private getSellers = this.getdata.appconstant + 'getSellers';
  private getStaff = this.getdata.appconstant + 'getStaff';
  private getDueTerms = this.getdata.appconstant + 'getDueTerms';
  private createEstimate = this.getdata.appconstant + 'createEstimate';
  private getInvoiceLabel = this.getdata.appconstant + 'getInvoiceLabel';
  private getEstimatesNextNumber = this.getdata.appconstant + 'getEstimatesNextNumber';
  estimateobj: any;
  myForm: FormGroup;
  details: any;
  lastadditem = false;
  addseller = false;
  ngOnInit() {
    this.modaldatatesting.displaydata.subscribe((data) => {
      if (data == "addseller") {
        this.addseller = true;
        this.getInvoiceFromData();
      } else if (data == "addcustomer") {
        this.lastaddcust = true;
        this.getCustomerData();
      } else if (data == "additem") {
        this.lastadditem = true;
        this.getProductData();
      } else if (data == "editSeller") {
        this.getInvoiceFromData();
      } else if (data == "closesellermodal") {
        if (this.addseller == false) {
          var getdata = this.myForm.value;
          getdata.sellerid = null;
          this.myForm.patchValue(getdata);
        }
      } else if (data == "closescutomermodal") {
        if (this.lastaddcust == false) {
          var getdata = this.myForm.value;
          getdata.customeridfull = null;
          this.myForm.patchValue(getdata);
        }
      } else if (data == "closesitemmodal") {
        if (this.lastadditem == false) {
          var getdata = this.myForm.get("details").value;
          getdata[this.globalproductindex].productdetails = null;
          this.myForm.get('details').patchValue(getdata);
        }
      }
    });
    this.details = [{
      productdetails: null,
      hsn: "",
      description: "",
      price: 0,
      discount: 0,
      discounttype: "percentage",
      quantity: 0,
      total: 0,
      itemnumbererror: "",
      cgst: 0,
      sgst: 0,
      igst: 0
    }]
    this.states = [
      { text: 'Andhra Pradesh', value: 'Andhra Pradesh' },
      { text: 'Arunachal Pradesh', value: 'Arunachal Pradesh' },
      { text: 'Assam', value: 'Assam' },
      { text: 'Bihar', value: 'Bihar' },
      { text: 'Chandigarh', value: 'Chandigarh' },
      { text: 'Chhattisgarh', value: 'Chhattisgarh' },
      { text: 'Dadra and Nagar Haveli', value: 'Dadra and Nagar Havelis' },
      { text: 'Daman and Diu', value: 'Daman and Diu' },
      { text: 'Delhi', value: 'Delhi' },
      { text: 'Goa', value: 'Goa' },
      { text: 'Gujarat', value: 'Gujarat' },
      { text: 'Haryana', value: 'Haryana' },
      { text: 'Himachal Pradesh', value: 'Himachal Pradesh' },
      { text: 'Jammu and Kashmir', value: 'Jammu and Kashmir' },
      { text: 'Jharkhand', value: 'Jharkhand' },
      { text: 'Karnataka', value: 'Karnataka' },
      { text: 'Kerala', value: 'Kerala' },
      { text: 'Lakshadweep', value: 'Lakshadweep' },
      { text: 'Madhya Pradesh', value: 'Madhya Pradesh' },
      { text: 'Maharashtra', value: 'Maharashtra' },
      { text: 'Manipur', value: 'Manipur' },
      { text: 'Meghalaya', value: 'Meghalaya' },
      { text: 'Mizoram', value: 'Mizoram' },
      { text: 'Nagaland', value: 'Nagaland' },
      { text: 'Odisha', value: 'Odisha' },
      { text: 'Puducherry', value: 'Puducherry' },
      { text: 'Punjab', value: 'Punjab' },
      { text: 'Rajasthan', value: 'Rajasthan' },
      { text: 'Sikkim', value: 'Sikkim' },
      { text: 'Tamil Nadu', value: 'Tamil Nadu' },
      { text: 'Telangana', value: 'Telangana' },
      { text: 'Tripura', value: 'Tripura' },
      { text: 'Uttar Pradesh', value: 'Uttar Pradesh' },
      { text: 'Uttarakhand', value: 'Uttarakhand' },
      { text: 'West Bengal', value: 'West Bengal' },
    ];
    /** Get Product Details */
    this.getProductData();

    /** Get Customer Data */
    this.getCustomerData();

    /*** Get Invoice From */
    this.getInvoiceFromData();

    /** Get Sales Person Data */
    this.getSalesPersonData();

    /** Get invoice Next Number */
    // this.getinvoicenextnumber();

    /** Shipping Information show/hide */
    this.showSelected = false;

    //this.onChanges();
    this.getdueterms();
    this.myFormform();
  }
  globalproductindex: any;
  triggeritemmodal(event, i) {
    this.globalproductindex = i;
    if (event.target.value == '') {

      $('#additemmodal').modal('show');

    }
    else {
      this.onChanges(i);
    }
  }
  myFormform() {
    this.showSelected = false;
    this.myForm = this.Formbuilder.group({
      sellerid: ['', [Validators.required]],
      sellerappcode: [this.appcode],
      userid: [this.userid],
      customeridfull: ['', [Validators.required]],
      customerid: ['', [Validators.required]],
      shippingaddress: [''],
      placeofsupply: ['', [Validators.required]],
      total: [0],
      amountdue: [0],
      customernotes: [''],
      terms: [""],
      discount: [0],
      amountpaid: [0],
      ibillaccount: null,
      details: this.Formbuilder.array([this.createItem()])
    });
  }

  createItem(): FormGroup {
    return this.Formbuilder.group({
      productdetails: [null, [Validators.required]],
      productid: [""],
      producttype: [''],
      hsn: '',
      description: '',
      price: [0, [Validators.required]],
      discount: 0,
      discounttype: 'percentage',
      quantity: [1, [Validators.required]],
      total: 0,
      cgst: 0,
      sgst: 0,
      igst: 0,
    });
  }
  addRow(): void {
    // let fg = this.FormBuilder.group(new this.createItem());
    // this.details.push(fg);	 
    this.details = this.myForm.get('details') as FormArray;
    this.details.push(this.createItem());
  }
  showNotification(from, align, msg) {
    const type = ['success'];
    const color = Math.floor(1);
    $.notify({
      icon: 'notifications',
      message: msg

    }, {
        type: type[color],
        timer: 4000,
        placement: {
          from: from,
          align: align
        }
      });
  }

  /** Add new row */
  // addRow() {

  //   this.details.push({
  //     productdetails: "",
  //     hsn: "",
  //     description: "",
  //     price: "",
  //     discount: "",
  //     discounttype: "percentage",
  //     quantity: 0,
  //     total: 0,
  //     itemnumbererror: "",
  //     cgst: 0,
  //     sgst: 0,
  //     igst: 0
  //   });

  // }

  /** Delete Row */
  deleteRow(rowNumber) {
    // this.estimateobj.estimate.details.splice(rowNumber, 1);
    this.details = this.myForm.get('details') as FormArray;
    this.details.removeAt(rowNumber);
    this.calc();
  }

  /** Get Invoice Next Number */
  getinvoicenextnumber(event) {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.getEstimatesNextNumber, datatype, 'post')
      .subscribe(
        data => {
          this.estimatenextnumber = data.estid;
        },
        Error => {

        }
      );
  }

  /** Get Product Details */
  getProductData() {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.getProducts, datatype, 'post')
      .subscribe(
        data => {
          this.getProductdata = data;
          // {{getProduct._id}}|{{getProduct.productname}}|{{getProduct.producttype}}
          if (this.lastadditem == true) {
            // {{getProduct._id}}|{{getProduct.productname}}|{{getProduct.producttype}}
            var getdata = this.myForm.get('details').value;
            getdata[this.globalproductindex].productdetails = data[0]._id + "|" + data[0].productname + "|" + data[0].producttype;
            this.myForm.get('details').patchValue(getdata);
            this.onChanges(this.globalproductindex);

          }
        }
        ,
        Error => {

        }
      );
  }

  /** Get All Value On Selected Product */
  changeprice(event, index) {
    // console.log(index);
    var tmp = event.target.value.split('|');
    var product_id = tmp[0];
    var datatype = "appcode=" + this.appcode + "&prodid=" + product_id;
    return this.makeapi.method(this.getSingleProduct, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          data[index].price = data.productprice
          this.raiseInvoiceForm.get('invoice.details').patchValue(data);
        },
        Error => {
          console.log("Error While Processing Changing product name");
        }
      )
  }

  /** Get Product Details */
  getCustomerData() {
    var useridobj = { "userid": this.userid }
    var datatype = "appcode=" + this.appcode + "&userid=" + JSON.stringify(useridobj);
    return this.makeapi.method(this.getCustomer, datatype, 'post')
      .subscribe(
        data => {

          this.getCustomerdata = data;
          var getdata = this.myForm.value;
          if (this.lastaddcust == true) {
            this.showSelected = true;
            if (data[0].ibillaccount == undefined) {
              var getdata = this.myForm.value;
              getdata.customeridfull = data[0].address + "|" + data[0]._id + "|" + data[0].customername + "|" + data[0].city + "|" + data[0].homestate + "|" + data[0].country + "|" + data[0].zip + "|" + data[0].street + "|";
              getdata.customerid = data[0]._id;
              this.dynamic_shipping_addr(getdata.customeridfull);
              this.checkstate();
            } else {
              var getdata = this.myForm.value;
              getdata.customeridfull = data[0].address + "|" + data[0]._id + "|" + data[0].customername + "|" + data[0].city + "|" + data[0].homestate + "|" + data[0].country + "|" + data[0].zip + "|" + data[0].street + "|" + true;
              getdata.customerid = data[0]._id;
              this.dynamic_shipping_addr(getdata.customeridfull);
              getdata.ibillaccount = true;
              this.checkstate();
            }
            var temp = getdata.customeridfull.split('|');
            this.getCustomerid = temp[1];
            this.getShippingAddress = temp[0];
            this.getShippingName = temp[2];
            this.getShippingCity = temp[3];
            this.getShippingState = temp[4];
            this.getShippingCountry = temp[5];
            this.getShippingzip = temp[6];
            this.getShippingStreet = temp[7];
            if (temp[8] == "") {
              this.myForm.get('ibillaccount').disable();
            } else {
              this.myForm.get('ibillaccount').enable();
              var getdata = this.myForm.value;
              getdata.ibillaccount = true;
            }
          }
          this.raiseInvoiceForm.patchValue(getdata);
        },
        Error => {

        }
      )
  }

  /** Get Invoice From or Seller Date */
  getInvoiceFromData() {
    var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getSellers, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          this.getCredentialsdata = data;
          var getdata = this.myForm.value;
          data.forEach(x => {
            if (x.isDefault == true) {
              getdata.sellerid = x._id;
              this.getinvoicenextnumber("")
            }
          })
          this.myForm.patchValue(getdata);
        },
        Error => {

        }
      )
  }

  /** Get Sales Person */
  getSalesPersonData() {
    var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getStaff, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          this.getSalesPerson = data;
        },
        Error => {

        }
      );
  }

  /** Add New Contact */
  fromaddrchanged(event) {
    if (event.target.value == 'addcontact') {
      $('#exampleModal2').modal('show');
    } else {
      this.getinvoicenextnumber(event.target.value);
    }
  }

  /** Add New Customer */
  toaddrchanged(event) {
    if (event.target.value == 'addcustomer') {
      this.showSelected = false;
      $('#customerModal2').modal('show');
    } else {
      this.showSelected = true;
      var temp = event.target.value.split('|');
      this.getCustomerid = temp[1];
      this.getShippingAddress = temp[0];
      this.getShippingName = temp[2];
      this.getShippingCity = temp[3];
      this.getShippingState = temp[4];
      this.getShippingCountry = temp[5];
      this.getShippingzip = temp[6];
      this.getShippingStreet = temp[7];
      if (temp[8] == "") {
        this.myForm.get('ibillaccount').disable();
      } else {
        this.myForm.get('ibillaccount').enable();
        var getdata = this.myForm.value;
        getdata.ibillaccount = true;
      }
      /** Pass cutomer id to hidden field */
      var getdata = this.myForm.value;
      getdata.customerid = this.getCustomerid;
      this.myForm.patchValue(getdata);
    }
  }

  /** Add New Sales Person */
  salesperson(event) {
    if (event.target.value == 'add_salesperson') {
      $('#salespersonModal2').modal('show');
    } else {
    }
  }

  // /** Add Configuration */
  // toaddconfig(event) {
  //   if (event.target.value == 'configuration') {
  //     $('#configurationModal2').modal('show');
  //   } else if (event.target.value == 'custom') {
  //     var getdata = this.raiseInvoiceForm.get('invoice').value;
  //     getdata.duedate = new Date();
  //     this.raiseInvoiceForm.get('invoice').patchValue(getdata);
  //   }
  //   else {
  //     var noncustom = event.target.value;
  //     var getdata = this.raiseInvoiceForm.get('invoice').value;
  //     this.duedate = new Date();
  //     getdata.duedate = new Date(this.duedate.setDate(this.duedate.getDate() + + noncustom));
  //     this.raiseInvoiceForm.get('invoice').patchValue(getdata);
  //   }
  // }

  /** Check State */
  checkstate() {
    var customer_id = this.myForm.value.customeridfull;
    // console.log(customer_id);
    if (customer_id != null) {
      var customer_split = customer_id.split("|");
      console.log(customer_split);
      var customer_state = customer_split[4];
      var check_placeofsupply = this.myForm.value.placeofsupply;
      if (customer_state == check_placeofsupply) {
        this.check_place = 'true';
        // console.log("check_place: " + this.check_place);
        var valuelen = this.myForm.get('details').value.length;
        // console.log("valuelen: " + valuelen);
        for (var i = 0; i < valuelen; i++) {
          this.onChanges(i);
        }
      } else {
        this.check_place = 'false';
        valuelen = this.myForm.get('details').value.length;
        // console.log("valuelen: " + valuelen);
        for (var i = 0; i < valuelen; i++) {
          this.onChanges(i);
        }
      }
    } else {
      this.check_place = '';
      // console.log("check_place: " + this.check_place);
    }
  }

  get myFormdetails() { return <FormArray>this.myForm.get('details') as FormArray }

  /** Change Row data on change */
  onChanges(index) {
    // this.checkstate();
    var getdata = this.myForm.get('details').value;
    var row_description = getdata[index].productdetails;
    if (row_description == null) {
      return false;
    }
    var row_quantity = getdata[index].quantity;
    var row_discount = getdata[index].discount;
    var tmp = row_description.split('|');
    var product_id = tmp[0];
    getdata[index].description = tmp[1];
    getdata[index].productid = tmp[0];
    getdata[index].producttype = tmp[2];
    var datatype = "appcode=" + this.appcode + "&prodid=" + product_id;
    this.makeapi.method(this.getSingleProduct, datatype, 'post')
      .subscribe(
        data => {

          getdata[index].price = data.productprice;
          getdata[index].hsn = data.hsn;
          if (this.check_place == 'true') {
            getdata[index].cgst = data.cgst;
            getdata[index].sgst = data.sgst;
            getdata[index].igst = 0;
          } else if (this.check_place == 'false') {
            getdata[index].cgst = 0;
            getdata[index].sgst = 0;
            getdata[index].igst = data.igst;
          } else {
            getdata[index].cgst = data.cgst;
            getdata[index].sgst = data.sgst;
            getdata[index].igst = data.igst;
          }

          /** Get row Total */
          getdata[index].total = data.productprice * row_quantity;

          // if ((row_discount == '') && (row_discount == 0)) {
          //   console.log("row_total: " + this.estimateobj.estimate.details[index].total)
          // } else {
          //   var getamt = data.productprice * row_quantity;
          //   this.estimateobj.estimate.details[index].total = getamt - (getamt * row_discount / 100);
          //   console.log("row_total: " + this.estimateobj.estimate.details[index].total)
          // }
          // console.log("row_total: " + this.details[index].total)

          /** Get Discout price */
          getdata[index].discount = row_discount;

          this.myForm.get('details').patchValue(getdata);
          this.calc();
        },
        Error => {
          console.log("Errow While Processing Changing product name");
        }
      )
  }
  isdetailsdiscount: any;
  isdiscount: any = true;;

  alldiscountchanged(e) {

    var arraylength = this.myForm.get('details').value.length;
    var details = this.myForm.get('details').value;

    if (e.target.checked == true) {

      for (var i = 0; i < arraylength; i++) {
        details[i].discount = 0
        this.myForm.get('details').patchValue(details);
        this.isdetailsdiscount = true;
        this.isdiscount = false;
        this.onChanges(i)
      }
    }
    else {
      this.myForm.get('discount').patchValue('0');
      this.isdetailsdiscount = false;
      this.isdiscount = true;
      for (var i = 0; i < arraylength.length; i++) {

        this.onChanges(i)

      }
    }

  }
  // Calclutaion Area
  total_amt: number
  total_amt_wt: number
  calc() {
    var details = this.myForm.get('details').value;
    var getdata = this.myForm.value;
    var totaldiscount = getdata.discount;
    var amountpaid = getdata.amountpaid;
    var totallength = details.length;
    var total_amt = 0;
    var total_amt_wt = 0;
    getdata.total = 0;
    for (var j = 0; j < totallength; j++) {
      /** Tax Calculation */
      var discounted_amt = details[j].total - ((details[j].discount / 100) * details[j].total);
      getdata.total += ((((Number(details[j].cgst) + Number(details[j].sgst) + Number(details[j].igst)) / 100) * discounted_amt) + discounted_amt).toFixed(2);  // Amount with Tax
      getdata.total = Number(getdata.total);
      // total_amt += details[j].total; //Amount without tax
    }
    if (totaldiscount > 0) {
      getdata.amountdue = ((getdata.total - (getdata.total * (totaldiscount / 100))) - amountpaid).toFixed(2);
      getdata.amountdue = Number(getdata.amountdue);
    } else {
      getdata.amountdue = (getdata.total - amountpaid).toFixed(2);
      getdata.amountdue = Number(getdata.amountdue);
    }
    this.myForm.get('details').patchValue(details);
    this.myForm.patchValue(getdata);

  }

  /** Get Due date */
  getdueterms() {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.getDueTerms, datatype, 'post')
      .subscribe(
        data => {
          this.duetermsdata = data;
        },
        Error => {

        }
      );
  }

  /** Payment date on change */
  onValueChange(value: Date): void {
    // console.log(value);
    var getdata = this.raiseInvoiceForm.get('invoice').value;
    getdata.payment_terms = '';
    this.raiseInvoiceForm.get('invoice').patchValue(getdata);
  }

  /** Raise Invoice */
  createestimate() {
    // console.log(this.estimateform.value.estimateobj);
    var to_id = this.myForm.value.customeridfull; // Get customer id
    var to_id = to_id.split('|'); // Get customer id
    var customerid = to_id[1]; // Get customer id
    var appcode = this.appcode;
    var userid = this.userid;
    var sellerid = this.myForm.value.sellerid;
    var shippingaddress = this.myForm.value.shippingaddress;
    this.myForm.get('customeridfull').disable();
    var getcontrol = this.myForm.get('details').value;
    getcontrol.forEach(data => {
      // console.log(data);
      delete data.productdetails;
    });

    // var datatype = 'userid=' + userid + '&sellerid=' + sellerid + "&customerid=" + customerid + "&shippingaddress=" + shippingaddress + "&invoice=" + JSON.stringify( this.myForm.value) + "&appcode=" + appcode;
    var datatype = "estimate=" + JSON.stringify(this.myForm.value) + "&appcode=" + appcode;

    return this.makeapi.method(this.createEstimate, datatype, 'post')
      .subscribe(
        data => {
          this.myForm.get('customeridfull').enable();
          if (data.status == "success") {
            this.getdata.showNotification('bottom', 'right', 'Estimate Created Successfully', "success");
            this.myFormform();
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {

        }
      );
  }

  dynamic_shipping_addr(event) {
    var temp = event.split('|');
    var address = temp[0] + ', ' + temp[3] + ', ' + temp[4] + ', ' + temp[5] + ', ' + temp[6];
    var getdata = this.myForm.value;
    getdata.shippingaddress = address;
    this.myForm.patchValue(getdata);
  }

}
