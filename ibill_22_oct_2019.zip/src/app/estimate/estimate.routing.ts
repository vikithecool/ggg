import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EstimateComponent } from "./estimate.component";


const routes: Routes = [
  { path: '', component: EstimateComponent }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);