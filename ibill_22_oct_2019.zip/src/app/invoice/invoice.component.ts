import { Component, OnInit, Pipe, PipeTransform, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { IfObservable } from 'rxjs/observable/IfObservable';
declare var $;
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { AuthGuard } from '../canactivate.service';
import { modalvaluetesting } from '../modal.service';
import Swal from 'sweetalert2'

@Component({
  selector: 'app-invoice',
  templateUrl: './invoice.component.html',
  styleUrls: ['./invoice.component.css']
})
export class InvoiceComponent implements OnInit {
  /** Add New Row */
  rowData: any;
  hsn: any;
  description: any;
  price: any;
  discount: any;
  discounttype: "percentage";
  quantity: any;
  total: any;
  itemnumbererror: any;
  stockerror: any;
  descriptionerror: any;
  priceerror: any;
  discounterror: any;
  quantityerror: any;
  cgst: any;
  sgst: any;
  igst: any;
  addseller = false;
  /** Get Product Details */
  getProductdata: any;

  /** Get All Value On Selected Product */
  rowdata: any;
  prod_total = [];


  /** Get Customer Data */
  getCustomerdata: any;

  /** Get Invoice From  Data */
  getCredentialsdata: any;

  /** Get All states */
  states: any;

  /** Get Sales Person Details */
  getSalesPerson: any;

  formattedMessage: any;


  /** Show Shipping details */
  getCustomerid: any;
  getShippingAddress: any;
  getShippingName: any;
  getShippingCity: any;
  getShippingState: any;
  getShippingCountry: any;
  getShippingzip: any;
  getShippingStreet: any;
  showSelected: any = 'false';

  /** Craeate Invoice */
  raiseInvoiceForm: FormGroup;
  details: FormArray;
  additemform: FormGroup;
  /** Onchange Calcultaion */
  summed: number;

  /**  Check Place */
  check_place = '';

  /** Add Configurtaion */
  dueterms: string;

  /** Set todays date */
  today = Date.now();
  msg: any;

  /** GEt Payment Due terms */
  duetermsdata: any;
  bsValue = new Date();
  duedate: Date = new Date();

  /** Get Invoice Next Number */
  invoicenextnumber: any;

  /** Gert Shipping Address */
  dynamicshippingaddress: any;

  /** get Discout value on change */
  condition: boolean = true;
  isalldiscount: boolean = true;

  /** SET UTGST/SGST */
  utgst: any = 'SGST';

  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;
  lictype: any;
  freeUser: any = 'false';

  lastaddcust = false;
  emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  numbervalidation = /^[1-9]+$/;
  alphanumeric = /^[a-zA-Z0-9]+$/;
  decimalnumber = /^(0|[1-9]\d*)(\.\d+)?$/;
  alphawithdot = /^[a-zA-Z. ]+$/;
  alpha = /^[a-zA-Z]+$/;

  minDate: Date;
  constructor(private modaldatatesting: modalvaluetesting, private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http, private ref: ChangeDetectorRef) {
    // this.raiseInvoiceForm.get('invoice.discount').disable();
    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
    this.lictype = this.getsession.session().lictype;
    this.raiseinvoiceform();

  }

  createItem(): FormGroup {
    return this.Formbuilder.group({
      hsn: '',
      productdetails: [null, Validators.compose([Validators.required])],
      price: [0],
      description: [null],
      productid: [null],
      producttype: [null],
      discount: [0],
      discounttype: '',
      quantity: [1, [Validators.required]],
      total: '',
      cgst: "",
      sgst: "",
      igst: ""
    });
  }

  raiseinvoiceform() {
    this.showSelected = 'false';
    /** Create Invoice */
    this.raiseInvoiceForm = this.Formbuilder.group({
      sellerid: [null, Validators.compose([Validators.required])],
      sellerappcode: [this.appcode, Validators.compose([Validators.required])],
      customerid: [null, Validators.compose([Validators.required])],
      customerid_full: [null],
      shippingaddress: [null],

      invoicename: [null, Validators.compose([Validators.required])],
      raiseddate: [new Date(), Validators.compose([Validators.required])],
      duedate: [new Date(), Validators.compose([Validators.required])],
      placeofsupply: [null, Validators.compose([Validators.required])],
      salespersonusername: [""],
      roundoff: [0],
      total: [0],
      discount: [0],
      amountpaid: [0],
      amountdue: [0],
      customernotes: [null],
      ibillaccount: [null],
      payment_terms: "custom",
      terms: [null],
      details: this.Formbuilder.array([this.createItem()]),

    });
  }

  private getProducts = this.getdata.appconstant + 'getProducts';
  private getSingleProduct = this.getdata.appconstant + 'getProduct';
  private getCustomer = this.getdata.appconstant + 'getCustomer';
  private getSellers = this.getdata.appconstant + 'getSellers';
  private getStaff = this.getdata.appconstant + 'getStaff';
  private getDueTerms = this.getdata.appconstant + 'getDueTerms';
  private raiseInvoice = this.getdata.appconstant + 'raiseInvoice';
  private getInvoiceLabel = this.getdata.appconstant + 'getInvoiceLabel';
  private getInvoiceNextNumber = this.getdata.appconstant + 'getInvoiceNextNumber';
  private saveInvoiceDraft = this.getdata.appconstant + 'saveInvoiceDraft';
  private clearInvoiceDraft = this.getdata.appconstant + 'clearInvoiceDraft';
  private getInvoicePageData = this.getdata.appconstant + 'getInvoicePageData';

  dates: any;

  ngOnInit() {
    //   if (this.getsession != null) {
    //     this.appcode = this.getsession.appcode;
    //     this.userid = this.getsession.id;
    //     this.logintype = this.getsession.type;
    //     this.user_email = this.getsession.email;
    // }

    var getdata = this.raiseInvoiceForm.value;
    this.minDate = new Date(getdata.raiseddate);
    getdata.duedate.setDate(this.minDate.getDate());
    this.minDate.setDate(this.minDate.getDate());
    this.raiseInvoiceForm.patchValue(getdata);

    this.modaldatatesting.displaydata.subscribe((data) => {
      if (data == "addseller") {
        this.addseller = true;
        this.getInvoiceFromData();
      } else if (data == "addcustomer") {
        this.lastaddcust = true;
        this.getCustomerData();
      } else if (data == "additem") {
        this.lastadditem = true;
        this.getProductData();
      } else if (data == "adddueterm") {
        this.getdueterms();
      } else if (data == "closesellermodal") {

        if (this.addseller == false) {
          var getdata = this.raiseInvoiceForm.value;
          getdata.sellerid = null;
          this.raiseInvoiceForm.patchValue(getdata);
        }


      } else if (data == "closescutomermodal") {
        if (this.lastaddcust == false) {
          var getdata = this.raiseInvoiceForm.value;
          getdata.customerid_full = null;
          this.raiseInvoiceForm.patchValue(getdata);
        }
      } else if (data == "closesitemmodal") {

        if (this.lastadditem == false) {
          var getdata = this.raiseInvoiceForm.get("details").value;
          getdata[this.globalproductindex].productdetails = null;
          this.raiseInvoiceForm.get('details').patchValue(getdata);
        }


      } else if (data == "editSeller") {
        this.getInvoiceFromData();
      }
      else if (data == "closestermsmodal") {
        // this.getInvoiceFromData();
        var getdata = this.raiseInvoiceForm.value;
        getdata.payment_terms = 'custom';
        this.raiseInvoiceForm.patchValue(getdata);
        this.toaddconfig('custom')
      }
    });
    this.dates = new Date();

    this.states = [
      { text: 'Andhra Pradesh', value: 'Andhra Pradesh' },
      { text: 'Arunachal Pradesh', value: 'Arunachal Pradesh' },
      { text: 'Assam', value: 'Assam' },
      { text: 'Bihar', value: 'Bihar' },
      { text: 'Chandigarh', value: 'Chandigarh' },
      { text: 'Chhattisgarh', value: 'Chhattisgarh' },
      { text: 'Dadra and Nagar Haveli', value: 'Dadra and Nagar Havelis' },
      { text: 'Daman and Diu', value: 'Daman and Diu' },
      { text: 'Delhi', value: 'Delhi' },
      { text: 'Goa', value: 'Goa' },
      { text: 'Gujarat', value: 'Gujarat' },
      { text: 'Haryana', value: 'Haryana' },
      { text: 'Himachal Pradesh', value: 'Himachal Pradesh' },
      { text: 'Jammu and Kashmir', value: 'Jammu and Kashmir' },
      { text: 'Jharkhand', value: 'Jharkhand' },
      { text: 'Karnataka', value: 'Karnataka' },
      { text: 'Kerala', value: 'Kerala' },
      { text: 'Lakshadweep', value: 'Lakshadweep' },
      { text: 'Madhya Pradesh', value: 'Madhya Pradesh' },
      { text: 'Maharashtra', value: 'Maharashtra' },
      { text: 'Manipur', value: 'Manipur' },
      { text: 'Meghalaya', value: 'Meghalaya' },
      { text: 'Mizoram', value: 'Mizoram' },
      { text: 'Nagaland', value: 'Nagaland' },
      { text: 'Odisha', value: 'Odisha' },
      { text: 'Puducherry', value: 'Puducherry' },
      { text: 'Punjab', value: 'Punjab' },
      { text: 'Rajasthan', value: 'Rajasthan' },
      { text: 'Sikkim', value: 'Sikkim' },
      { text: 'Tamil Nadu', value: 'Tamil Nadu' },
      { text: 'Telangana', value: 'Telangana' },
      { text: 'Tripura', value: 'Tripura' },
      { text: 'Uttar Pradesh', value: 'Uttar Pradesh' },
      { text: 'Uttarakhand', value: 'Uttarakhand' },
      { text: 'West Bengal', value: 'West Bengal' },
    ];
    /** Get Product Details */
    this.getProductData();

    /** Get Customer Data */
    this.getCustomerData();

    /*** Get Invoice From */
    this.getInvoiceFromData();

    /** Get Sales Person Data */
    this.getSalesPersonData();

    /** Get invoice Next Number */
    // this.getinvoicenextnumber();

    /** Shipping Information show/hide */
    this.showSelected = 'false';

    //this.onChanges();
    this.getdueterms();

    this.getInvoicepagedata();
  }

  showNotification(from, align, msg) {
    const type = ['success'];
    const color = Math.floor(1);
    $.notify({
      icon: 'notifications',
      message: msg

    }, {
        type: type[color],
        timer: 4000,
        placement: {
          from: from,
          align: align
        }
      });
  }
  onChangeraisedate(event) {

    var duedate = this.raiseInvoiceForm.value.duedate;
    if (duedate < event) {
      var getdata = this.raiseInvoiceForm.value;
      this.minDate = event;
      getdata.duedate = new Date(event);
      getdata.raiseddate = new Date(event);
      this.raiseInvoiceForm.patchValue(getdata);
    } else if (duedate == event) {

    } else {
      this.minDate = new Date(event);
      this.minDate.setDate(this.minDate.getDate());
    }
  }
  /** Add new row */
  addRow(): void {
    // let fg = this.FormBuilder.group(new this.createItem());
    // this.details.push(fg);	 
    this.details = this.raiseInvoiceForm.get('details') as FormArray;
    this.details.push(this.createItem());

    // this.rowData.push(
    //   {
    //     productid: "",
    //     hsn: "",
    //     description: "",
    //     price: "",
    //     discount: "",
    //     discounttype: "percentage",
    //     quantity: "",
    //     total: '',
    //     itemnumbererror: "",
    //     stockerror: "",
    //     descriptionerror: "",
    //     priceerror: "",
    //     discounterror: "",
    //     quantityerror: "",
    //     cgst: "",
    //     sgst: "",
    //     igst: ""
    //   }
    // )
  }

  /** Delete Row */
  deleteRow(rowNumber) {
    // this.rowData.splice(rowNumber, 1);
    this.details = this.raiseInvoiceForm.get('details') as FormArray;
    this.details.removeAt(rowNumber);
    this.calc();
  }

  /** Get Invoice Next Number */
  getinvoicenextnumber(event) {
    var datatype = "appcode=" + this.appcode + "&sellerid=" + event;
    return this.makeapi.method(this.getInvoiceNextNumber, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          if (data.labelprefix) {
            this.invoicenextnumber = data.labelprefix + data.nextnumber;
          } else {
            this.invoicenextnumber = data.nextnumber;
          }
          var getdata = this.raiseInvoiceForm.value;
          getdata.invoicename = (this.invoicenextnumber).toString();
          this.raiseInvoiceForm.patchValue(getdata);
        },
        Error => {

        }
      );
  }
  lastadditem = false;
  /** Get Product Details */
  getProductData() {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.getProducts, datatype, 'post')
      .subscribe(
        data => {
          this.getProductdata = data;
          if (this.lastadditem == true) {
            // {{getProduct._id}}|{{getProduct.productname}}|{{getProduct.producttype}}
            var getdata = this.raiseInvoiceForm.get('details').value;
            getdata[this.globalproductindex].productdetails = data[0]._id + "|" + data[0].productname + "|" + data[0].producttype;
            this.raiseInvoiceForm.get('details').patchValue(getdata);
            this.onChanges(this.globalproductindex);
          }

        },
        Error => {

        }
      );
  }

  /** Get All Value On Selected Product */
  changeprice(event, index) {
    // console.log(index);
    var tmp = event.target.value.split('|');
    var product_id = tmp[0];
    var datatype = "appcode=" + this.appcode + "&prodid=" + product_id;
    return this.makeapi.method(this.getSingleProduct, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          data[index].price = data.productprice
          this.raiseInvoiceForm.get('details').patchValue(data);
        },
        Error => {
          console.log("Error While Processing Changing product name");
        }
      )
  }



  /** On change price */
  singlecalc(rowData) {
    this.rowdata = rowData;
    this.prod_total = [];
    for (var i = 0; i < this.rowdata.length; i++) {
      this.prod_total.push(this.rowdata[i].price * this.rowdata[i].quantity);
    }
  }
  /** On change price */
  totalcalc(rowData) {
    //console.log(rowData);
  }
  get raiseInvoiceFormdetails() { return <FormArray>this.raiseInvoiceForm.get('details') }


  /** Get Product Details */
  getCustomerData() {
    var useridobj = { "userid": this.userid }
    var datatype = "appcode=" + this.appcode + "&userid=" + JSON.stringify(useridobj);
    return this.makeapi.method(this.getCustomer, datatype, 'post')
      .subscribe(
        data => {
          this.getCustomerdata = data;
          var getdata = this.raiseInvoiceForm.value;
          if (this.lastaddcust == true) {
            this.showSelected = 'true';
            if (data[0].ibillaccount == undefined) {
              var getdata = this.raiseInvoiceForm.value;
              getdata.customerid_full = data[0].address + "|" + data[0]._id + "|" + data[0].customername + "|" + data[0].city + "|" + data[0].homestate + "|" + data[0].country + "|" + data[0].zip + "|" + data[0].street + "|";
              getdata.customerid = data[0]._id;
              this.dynamic_shipping_addr(getdata.customerid_full);
              this.checkstate();
            } else {
              var getdata = this.raiseInvoiceForm.value;
              getdata.customerid_full = data[0].address + "|" + data[0]._id + "|" + data[0].customername + "|" + data[0].city + "|" + data[0].homestate + "|" + data[0].country + "|" + data[0].zip + "|" + data[0].street + "|" + true;
              getdata.customerid = data[0]._id;
              this.dynamic_shipping_addr(getdata.customerid_full);
              getdata.ibillaccount = true;
              this.checkstate();
            }
            var temp = getdata.customerid_full.split('|');
            this.getCustomerid = temp[1];
            this.getShippingAddress = temp[0];
            this.getShippingName = temp[2];
            this.getShippingCity = temp[3];
            this.getShippingState = temp[4];
            this.getShippingCountry = temp[5];
            this.getShippingzip = temp[6];
            this.getShippingStreet = temp[7];
            if (temp[8] == "") {
              this.raiseInvoiceForm.get('ibillaccount').disable();
            } else {
              this.raiseInvoiceForm.get('ibillaccount').enable();
              var getdata = this.raiseInvoiceForm.value;
              getdata.ibillaccount = true;
            }
          }
          this.raiseInvoiceForm.patchValue(getdata);
        },
        Error => {

        }
      )
  }

  /** Get Invoice From or Seller Date */
  getInvoiceFromData() {
    var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getSellers, datatype, 'post')
      .subscribe(
        data => {
          console.log(data);
          if (this.lictype == 'free') {
            if (data.length > 0) {
              this.freeUser = 'true';
            }
          }
          this.getCredentialsdata = data;

          var getdata = this.raiseInvoiceForm.value;
          data.forEach(x => {
            if (x.isDefault == true) {
              getdata.sellerid = x._id;
              this.getinvoicenextnumber(x._id)
            }
          })
          this.raiseInvoiceForm.patchValue(getdata);
        },
        Error => {

        }
      )
  }

  /** Get Sales Person */
  getSalesPersonData() {
    var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getStaff, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          this.getSalesPerson = data;
        },
        Error => {

        }
      );
  }

  /** Add New Contact */
  fromaddrchanged(event) {

    if (event.target.value == 'addcontact') {
      $('#exampleModal2').modal('show');

    } else if (event.target.value == 'freetrial') {
      var ask = confirm('Upgrade to Pro');
      if (ask) {
        this.router.navigateByUrl('/checkout');
      }
    } else {

      this.getinvoicenextnumber(event.target.value);
    }
  }

  /** Add New Customer */
  toaddrchanged(event) {
    if (event.target.value == '' || event.target.value == undefined) {
      this.showSelected = 'false';
      $('#customerModal2').modal('show');
    } else {
      this.showSelected = 'true';
      var temp = event.target.value.split('|');
      this.getCustomerid = temp[1];
      this.getShippingAddress = temp[0];
      this.getShippingName = temp[2];
      this.getShippingCity = temp[3];
      this.getShippingState = temp[4];
      this.getShippingCountry = temp[5];
      this.getShippingzip = temp[6];
      this.getShippingStreet = temp[7];
      if (temp[8] == "") {
        this.raiseInvoiceForm.get('ibillaccount').disable();
      } else {
        this.raiseInvoiceForm.get('ibillaccount').enable();
        var getdata = this.raiseInvoiceForm.value;
        getdata.ibillaccount = true;
      }
      /** Pass cutomer id to hidden field */

    }
  }

  /** Add New Sales Person */
  salesperson(event) {
    if (event.target.value == 'add_salesperson') {
      $('#salespersonModal2').modal('show');
    } else {
    }
  }
  globalproductindex: any;
  triggeritemmodal(event, i) {
    this.globalproductindex = i;
    if (event == '') {

      $('#additemmodal').modal('show');

    }
    else {
      this.onChanges(i);
    }
  }
  /** Add Configuration */
  toaddconfig(event) {
    if (event == 'configuration') {
      $('#configurationModal2').modal('show');
    } else if (event == 'custom') {
      var getdata = this.raiseInvoiceForm.value;
      getdata.duedate = new Date();
      this.raiseInvoiceForm.patchValue(getdata);
    }
    else {
      var noncustom = event;
      var getdata = this.raiseInvoiceForm.value;
      this.duedate = new Date();
      getdata.duedate = new Date(this.duedate.setDate(this.duedate.getDate() + + noncustom));
      this.raiseInvoiceForm.patchValue(getdata);
    }
  }

  /** Check State */
  checkstate() {
    var customer_id = this.raiseInvoiceForm.value.customerid_full;
    // console.log(customer_id);
    if (customer_id != null) {
      var customer_split = customer_id.split("|");
      // console.log(customer_split);
      var customer_state = customer_split[4];
      var check_placeofsupply = this.raiseInvoiceForm.value.placeofsupply;
      console.log(customer_state);
      console.log(check_placeofsupply);
      if (customer_state == check_placeofsupply) {
        if ((customer_state = 'Chandigarh') && (check_placeofsupply == 'Chandigarh')) {
          this.utgst = 'UTGST';
        } else if ((customer_state = 'Dadra and Nagar Haveli') && (check_placeofsupply = 'Dadra and Nagar Haveli')) {
          this.utgst = 'UTGST';
        } else if ((customer_state = 'Lakshadweep') && (check_placeofsupply = 'Lakshadweep')) {
          this.utgst = 'UTGST';
        } else if ((customer_state = 'Puducherry') && (check_placeofsupply = 'Puducherry')) {
          this.utgst = 'UTGST';
        } else if ((customer_state = 'Andaman and Nicobar Islands') && (check_placeofsupply = 'Andaman and Nicobar Islands')) {
          this.utgst = 'UTGST';
        } else if ((customer_state = 'Delhi') && (check_placeofsupply = 'Delhi')) {
          this.utgst = 'UTGST';
        } else {
          this.utgst = 'SGST';
        }
        this.check_place = 'true';
        // console.log("check_place: " + this.check_place);
        var valuelen = this.raiseInvoiceForm.get('details').value.length;
        // console.log("valuelen: " + valuelen);
        var getdata = this.raiseInvoiceForm.value;
        getdata.customerid = this.getCustomerid;
        this.raiseInvoiceForm.patchValue(getdata);
        for (var i = 0; i < valuelen; i++) {
          this.onChanges(i);
        }
      } else {
        this.utgst = 'SGST';
        this.check_place = 'false';
        var valuelen = this.raiseInvoiceForm.get('details').value.length;
        // console.log("valuelen: " + valuelen);
        var getdata = this.raiseInvoiceForm.value;
        getdata.customerid = this.getCustomerid;
        this.raiseInvoiceForm.patchValue(getdata);
        for (var i = 0; i < valuelen; i++) {
          this.onChanges(i);
        }
      }
    } else {
      this.check_place = '';
      // console.log("check_place: " + this.check_place);
    }
  }


  /** Check State */
  // checkstate() {
  //   var customer_id = this.raiseInvoiceForm.value.customer_full;
  //   console.log(customer_id);
  //   if (customer_id != null) {
  //     var customer_split = customer_id.split("|");
  //     console.log(customer_split);
  //     var customer_state = customer_split[4];
  //     var check_placeofsupply = this.raiseInvoiceForm.value.placeofsupply;
  //     if (customer_state == check_placeofsupply) {
  //       this.check_place = 'true';
  //       console.log("check_place: " + this.check_place);
  //       var getdata = this.raiseInvoiceForm.value;
  //       getdata.customerid = customer_split[1];
  //       this.raiseInvoiceForm.patchValue(getdata);

  //       var valuelen = this.raiseInvoiceForm.get('details').value.length;
  //       console.log("valuelen: " + valuelen);
  //       for (var i = 0; i < valuelen; i++) {
  //         this.onChanges(i);
  //       }
  //     } else {
  //       this.check_place = 'false';
  //       var getdata = this.raiseInvoiceForm.value;
  //       getdata.customerid = customer_split[1];
  //       this.raiseInvoiceForm.patchValue(getdata);
  //       valuelen = this.raiseInvoiceForm.get('details').value.length;
  //       console.log("valuelen: " + valuelen);
  //       for (var i = 0; i < valuelen; i++) {
  //         this.onChanges(i);
  //       }
  //     }
  //   } else {
  //     this.check_place = '';
  //     console.log("check_place: " + this.check_place);
  //   }
  // }


  /** Change Row data on change */
  onChanges(index) {
    // this.checkstate();
    // console.log("onchange_check_place: " + this.check_place);
    var getdata = this.raiseInvoiceForm.get('details').value;
    var row_description = getdata[index].productdetails;
    if (getdata[index].productdetails != null) {
      var row_description = getdata[index].productdetails;
    }
    else {
      return false;
    }
    var row_quantity = getdata[index].quantity;
    var row_discount = getdata[index].discount;
    var tmp = row_description.split('|');
    var product_id = tmp[0];
    getdata[index].description = tmp[1];
    getdata[index].productid = tmp[0];
    getdata[index].producttype = tmp[2];
    var datatype = "appcode=" + this.appcode + "&prodid=" + product_id;
    this.makeapi.method(this.getSingleProduct, datatype, 'post')
      .subscribe(
        val => {
          getdata[index].price = val.productprice;
          getdata[index].hsn = val.hsn;
          if (this.check_place == 'true') {

            getdata[index].cgst = val.cgst;
            getdata[index].sgst = val.sgst;
            getdata[index].igst = 0;
          } else if (this.check_place == 'false') {
            getdata[index].cgst = 0;
            getdata[index].sgst = 0;
            getdata[index].igst = val.igst;
          } else {
            getdata[index].cgst = val.cgst;
            getdata[index].sgst = val.sgst;
            getdata[index].igst = val.igst;
          }

          /** Get row Total */
          getdata[index].total = val.productprice * row_quantity;
          // if ((row_discount == '') && (row_discount == 0)) {
          //   getdata[index].total = val.productprice * row_quantity;
          //   console.log("row_total: " + getdata[index].total)
          // } else {
          //   var getamt = val.productprice * row_quantity;
          //   getdata[index].total = getamt - (getamt * row_discount / 100);
          //   console.log("row_total: " + getdata[index].total)
          // }


          /** Get Discout price */
          // getdata[index].discount = row_discount;
          // console.log(row_discount);

          this.raiseInvoiceForm.get('details').patchValue(getdata);
          this.calc();
        },
        Error => {
          console.log("Errow While Processing Changing product name");
        }
      )
  }

  // Calclutaion Area
  total_amt: number
  total_amt_wt: number
  calc() {
    var details = this.raiseInvoiceForm.get('details').value;
    var getdata = this.raiseInvoiceForm.value;
    var totaldiscount = getdata.discount;
    var amountpaid = getdata.amountpaid;
    var roundoff = getdata.roundoff;
    var totallength = details.length;
    var total_amt = 0;
    var total_amt_wt = 0;
    getdata.total = 0;
    for (var j = 0; j < totallength; j++) {
      /** Tax Calculation */
      var discounted_amt = details[j].total - ((details[j].discount / 100) * details[j].total);
      console.log("discounted_amt: " + discounted_amt);
      getdata.total += ((((Number(details[j].cgst) + + Number(details[j].sgst) + + Number(details[j].igst)) / 100) * discounted_amt) + + discounted_amt);  // Amount with Tax
      getdata.total = Number((getdata.total).toFixed(2));
      console.log("total: " + getdata.total);
      // total_amt += details[j].total; //Amount without tax
    }
    if (totaldiscount > 0) {
      getdata.amountdue = (((getdata.total - (getdata.total * (totaldiscount / 100))) - amountpaid) + + roundoff).toFixed(2);
      getdata.amountdue = Number(getdata.amountdue);
      console.log("Amount Due: " + getdata.amountdue);
    } else {
      getdata.amountdue = ((getdata.total - amountpaid) + + roundoff).toFixed(2);
      getdata.amountdue = Number(getdata.amountdue);
      console.log("Amount Due: " + getdata.amountdue);
    }
    this.raiseInvoiceForm.patchValue(getdata);
  }

  /** Get Due date */
  getdueterms() {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.getDueTerms, datatype, 'post')
      .subscribe(
        data => {
          this.duetermsdata = data;
        },
        Error => {

        }
      );
  }

  /** Payment date on change */
  onValueChange(value: Date): void {
    var getdata = this.raiseInvoiceForm.value;
    getdata.payment_terms = 'custom';
    this.raiseInvoiceForm.patchValue(getdata);

  }

  /** Raise Invoice */
  raiseinvoice() {
    // var duedate = this.raiseInvoiceForm.value.duedate;
    // var raiseddate = this.raiseInvoiceForm.value.raiseddate;
    // if (duedate > raiseddate) {
    //   this.getdata.showNotification('bottom', 'right', 'Due date should not be greater than invoice date', "danger");
    //   return false;
    // } else if (duedate == raiseddate) {
    //   return true;
    // }
    var to_id = this.raiseInvoiceForm.value.customerid_full; // Get customer id
    var to_id = to_id.split('|'); // Get customer id
    var customerid = to_id[1]; // Get customer id
    var appcode = this.appcode;
    var userid = this.userid;
    var sellerid = this.raiseInvoiceForm.value.sellerid;
    var shippingaddress = this.raiseInvoiceForm.value.shippingaddress;

    this.raiseInvoiceForm.get('customerid_full').disable();
    // let control = this.raiseInvoiceForm.get('details').value;
    // this.raiseInvoiceForm.get('details').value.forEach(data => {
    //   control.description = control.description.split("|")[0];
    // })


    var duedate = this.raiseInvoiceForm.value.duedate;
    var currentdate = duedate.getDate();
    var currentmonth = duedate.getMonth() + 1; // January is 0!
    var month = currentmonth;
    var currentyear = duedate.getFullYear();
    var finaldate;
    var finalmonth;
    if (currentdate < 10) {
      finaldate = '0' + currentdate;
    }
    else {
      finaldate = currentdate;
    }
    if (currentmonth < 10) {
      finalmonth = '0' + currentmonth;
    }
    else {
      finalmonth = currentmonth
    }
    var getdata = this.raiseInvoiceForm.value;
    getdata.duedate = currentyear + "-" + finalmonth + "-" + finaldate;
    this.raiseInvoiceForm.patchValue(getdata);
    var raiseddate = this.raiseInvoiceForm.value.raiseddate;
    var currentdate = raiseddate.getDate();
    var currentmonth = raiseddate.getMonth() + 1; // January is 0!
    var month = currentmonth;
    var currentyear = raiseddate.getFullYear();
    var finaldate;
    var finalmonth;
    if (currentdate < 10) {
      finaldate = '0' + currentdate;
    }
    else {
      finaldate = currentdate;
    }
    if (currentmonth < 10) {
      finalmonth = '0' + currentmonth;
    }
    else {
      finalmonth = currentmonth
    }
    var getdata = this.raiseInvoiceForm.value;
    getdata.raiseddate = currentyear + "-" + finalmonth + "-" + finaldate;
    this.raiseInvoiceForm.patchValue(getdata);
    var getcontrol = this.raiseInvoiceForm.get('details').value;
    getcontrol.forEach(data => {
      delete data.productdetails;
    });
    var datatype = 'userid=' + userid + '&sellerid=' + sellerid + "&customerid=" + customerid + "&shippingaddress=" + shippingaddress + "&invoice=" + JSON.stringify(this.raiseInvoiceForm.value) + "&appcode=" + appcode;
    return this.makeapi.method(this.raiseInvoice, datatype, 'post')
      .subscribe(
        data => {
          this.raiseInvoiceForm.get('customerid_full').enable();
          if (data.status == "success") {
            this.getdata.showNotification('bottom', 'right', 'Invoice Raised Successfully', "success");
            this.raiseInvoiceForm.get('customerid_full').enable();
            this.raiseinvoiceform();
            this.getInvoiceFromData();
          } else if (data.status == "failure") {
            this.getdata.showNotification('bottom', 'right', 'Invoice Number Already Exists', "danger");
            this.raiseInvoiceForm.get('customerid_full').enable();
            this.raiseinvoiceform();
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {

        }
      );
  }

  dynamic_shipping_addr(event) {
    var temp = event.split('|');
    var address = temp[0] + ', ' + temp[3] + ', ' + temp[4] + ', ' + temp[5] + ', ' + temp[6];
    var getdata = this.raiseInvoiceForm.value;
    getdata.shippingaddress = address;
    this.raiseInvoiceForm.patchValue(getdata);
  }

  /** Get Discount on checkbox */
  isdetailsdiscount: any;
  isdiscount = true;
  alldiscountchanged(e) {

    var arraylength = this.raiseInvoiceForm.get('details').value.length;
    var details = this.raiseInvoiceForm.get('details').value;

    if (e.target.checked == true) {

      // this.raiseInvoiceForm.get('invoice.discount').enable();
      for (var i = 0; i < arraylength; i++) {
        details[i].discount = 0
        this.raiseInvoiceForm.get('details').patchValue(details);
        // this.raiseInvoiceForm.get('invoice.details').disable(details.discount);
        this.isdetailsdiscount = true;
        this.isdiscount = false;
        this.onChanges(i)
      }
    }
    else {
      // this.raiseInvoiceForm.get('invoice.discount').disable();
      this.raiseInvoiceForm.get('discount').patchValue('0');
      this.isdetailsdiscount = false;
      this.isdiscount = true;
      for (var i = 0; i < arraylength.length; i++) {

        this.onChanges(i)

      }
    }

  }

  href: any;
  canDeactivate(): Observable<any> | boolean {
    this.href = this.router.url;
    console.log(this.raiseInvoiceForm.touched);
    // return this.confirm('Do you want to save as draft?');
    //return this.confirm( 'Do you want to leave and save as draft?' );
    if (this.raiseInvoiceForm.touched) {
      Swal({
        title: 'Are you sure?',
        text: 'to save as draft!',
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes',
        cancelButtonText: 'No'
      }).then((result) => {
        if (result.value) {
          this.confirm('true');
          return true;
          // Swal(
          //   '',
          //   'Your file has been saved as draft.',
          //   'success'
          // )
          // For more information about handling dismissals please visit
          // https://sweetalert2.github.io/#handling-dismissals
        } else if (result.dismiss === Swal.DismissReason.cancel) {

        }
      })
      // return this.confirm('Do you want to save as draft?');
    } else {
      return true;
    }
  }
  confirm(message): Observable<boolean> {

    //const confirmation = window.confirm(message || 'Is it OK?');
    const confirmation = message = 'true';
    var issuccess = true;
    if (confirmation) {
      /** Raise Invoice */
      var to_id = this.raiseInvoiceForm.value.customerid_full; // Get customer id
      if (to_id != null) {
        var to_id = to_id.split('|'); // Get customer id
        var customerid = to_id[1]; // Get customer id
        var appcode = this.appcode;
        var userid = this.userid;
        var sellerid = this.raiseInvoiceForm.value.sellerid;
        var shippingaddress = this.raiseInvoiceForm.value.shippingaddress;
      }


      // let control = this.raiseInvoiceForm.get('details').value;
      // this.raiseInvoiceForm.get('details').value.forEach(data => {
      //   control.description = control.description.split("|")[0];
      // })
      var getcontrol = this.raiseInvoiceForm.get('details').value;
      getcontrol.forEach(data => {
        delete data.productdetails;
      });
      var datatype = 'userid=' + userid + '&sellerid=' + sellerid + "&customerid=" + customerid + "&shippingaddress=" + shippingaddress + "&invoice=" + JSON.stringify(this.raiseInvoiceForm.value) + "&appcode=" + this.appcode;
      this.makeapi.method(this.saveInvoiceDraft, datatype, 'post')
        .subscribe(
          data => {
            this.raiseInvoiceForm.get('customerid_full').enable();
            if (data.status == "success") {
              this.raiseInvoiceForm.reset();
              this.router.navigate(['dashboard/' + this.getdata.definedRouter]);
              this.getdata.showNotification('bottom', 'right', 'Invoice Saved Successfully', "success");
            } else if (data.status == "failure") {
              this.raiseInvoiceForm.get('customerid_full').enable();
              this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
            }
            else {
              this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");

            }
          },
          Error => {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");

          }
        );
    }
    else {
      var datatype = "appcode=" + this.appcode;
      this.makeapi.method(this.clearInvoiceDraft, datatype, 'post')
        .subscribe(
          data => {

          },
          Error => {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");

          }
        );
      // var reqdata = "appcode=" + appcode
      // this.makeapi.method(this.clearInvoiceDraft, reqdata, "post")
      //   .subscribe(data => {
      //     if (data.status == "success") {
      //     }
      //   });
    }
    return Observable.of(issuccess);
  };

  getInvoicepagedata() {
    this.makeapi.method(this.getInvoicePageData, 'userid=' + JSON.stringify({ "userid": this.userid }) + "&appcode=" + this.appcode, "post")

      .subscribe(data => {

        if (data.invoicedraft.status != "failure") {
          var shippingaddress = data.invoicedraft.details.shippingaddress;
          var getdata = this.raiseInvoiceForm.value;
          getdata.sellerid = data.invoicedraft.details.sellerid;
          getdata.customerid = data.invoicedraft.details.customerid;
          getdata.placeofsupply = data.invoicedraft.details.placeofsupply;
          getdata.shippingaddress = data.invoicedraft.details.shippingaddress;
          getdata.total = data.invoicedraft.details.total;
          getdata.amountdue = data.invoicedraft.details.amountdue;
          getdata.customernotes = data.invoicedraft.details.customernotes;
          getdata.terms = data.invoicedraft.details.terms;
          getdata.discount = data.invoicedraft.details.shippingaddress;
          getdata.amountpaid = data.invoicedraft.details.amountpaid;
          this.getinvoicenextnumber(data.invoicedraft.details.sellerid);
          getdata.customerid_full = data.invoicedraft.details.customerid_full;
          this.raiseInvoiceForm.patchValue(getdata);
          console.log(data.invoicedraft.details.shippingaddress);
          if ((data.invoicedraft.details.shippingaddress != null) && (data.invoicedraft.details.shippingaddress != '') && (data.invoicedraft.details.shippingaddress != "undefined") && (data.invoicedraft.details.shippingaddress != ", undefined, undefined, undefined, undefined")) {
            console.log(1)
            this.showSelected = 'true';
            var getShippingName = data.invoicedraft.details.shippingaddress.split(",");
            this.getShippingName = shippingaddress.split(",")[0];
            this.getShippingAddress = shippingaddress.split(",")[1];
            this.getShippingCity = shippingaddress.split(",")[2];
            this.getShippingState = shippingaddress.split(",")[3];
            this.getShippingzip = shippingaddress.split(",")[4];
          } else {
            this.showSelected = 'false';
          }



          let control = this.raiseInvoiceForm.get('details') as FormArray;
          control.removeAt(0);
          data.invoicedraft.details.details.forEach(data => {

            control.push(this.Formbuilder.group({
              productdetails: data.productid + "|" + data.description + '|' + data.producttype,
              productid: data.productid,
              producttype: data.producttype,
              hsn: data.hsn,
              description: data.description,
              price: data.price,
              discount: data.discount,
              discounttype: data.discounttype,
              quantity: data.quantity,
              total: data.total,
              cgst: data.cgst,
              sgst: data.sgst,
              igst: data.igst,
            }))
            // console.log(data)
          })

        }

      },
        Error => {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");

        });

  }
  resetraiseinvoiceform() {
    this.raiseinvoiceform();
    this.getInvoiceFromData();
  }
  amountpaidround() {
    var getdata = this.raiseInvoiceForm.value;
    getdata.amountpaid = Number(getdata.amountpaid).toFixed(2);
    getdata.amountpaid = Number(getdata.amountpaid)
    this.raiseInvoiceForm.patchValue(getdata);
    this.calc();
  }
  roundoffvalidation(event) {
    // this.calc();
    let charCode = (event.query) ? event.query : event.keyCode;
    // console.log(charCode);
    if (charCode = 31 && charCode != 189 && charCode != 190 && charCode != 8 && charCode != 37 && charCode != 39 && charCode != 9
      && (charCode < 48 || charCode > 57) && (charCode < 95 || charCode > 107) && charCode != 109 && charCode != 110)
      return false;
    return true;
  }

  roundoffround() {
    var getdata = this.raiseInvoiceForm.value;
    getdata.roundoff = Number(getdata.roundoff).toFixed(2);
    getdata.roundoff = Number(getdata.roundoff)
    this.raiseInvoiceForm.patchValue(getdata);
  }
}

