import { Component, OnInit, Injectable, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { isArray } from 'util';
import { AuthGuard } from '../canactivate.service';
declare var $;

@Component({
  selector: 'app-contacts',
  templateUrl: './contacts.component.html',
  styleUrls: ['./contacts.component.css']
})
export class ContactsComponent implements OnInit {

  private addCustomer = this.getdata.appconstant + 'addCustomer';
  private getCustomer = this.getdata.appconstant + 'getCustomer';
  private checkCustomerByAccount = this.getdata.appconstant + 'checkCustomerByAccount';
  private updateCustomer = this.getdata.appconstant + 'updateCustomer';
  private removeBulkCustomers = this.getdata.appconstant + 'removeBulkCustomers';
  private removeCustomer = this.getdata.appconstant + 'removeCustomer';

  /** Add Contact */
  addcustomerForm: FormGroup;
  editcustomerForm: FormGroup;
  /** View Customer */
  viewcustomerdata: any;

  /** Check Avaliablity */
  verifycontactForm: FormGroup;
  addcustomerFormfromcheck: FormGroup;

  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;

  /*** Is Customer */
  isCustomer: any = 'false';
  viewAdd: any = 'false';

  /** Is data */
  isData: any = 'false';

  states: any;
  contactdetails: any;
  p: number = 1;
  itemsPerPage: number = 8;
  emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  numbervalidation = /^[0-9,/]+$/;
  alphanumeric = /^[a-zA-Z0-9]+$/;
  alphawithdot = /^[a-zA-Z. ]+$/;
  phonevalidation = /^.{10,}$/;
  zipvalidation = /^.{6,6}$/;

  constructor(private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {

    this.addcustomerform();

    /** Add New contact */
    this.editcustomerForm = Formbuilder.group({
      'customername': [null, Validators.compose([Validators.required, Validators.pattern(this.alphawithdot), Validators.minLength(3), Validators.maxLength(40)])],
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'address': [null, Validators.compose([Validators.required])],
      'street': [null, Validators.compose([Validators.required])],
      'city': [null, Validators.compose([Validators.required])],
      'zip': [null, Validators.compose([Validators.required, , Validators.pattern(this.zipvalidation)])],
      'createdby': [this.userid],
      'country': [null, Validators.compose([Validators.required])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.phonevalidation)])],
      'homestate': [null, Validators.compose([Validators.required])],
      // 'createdbyname': ['superuser']
    });

    this.states = [
      { text: 'Andhra Pradesh', value: 'Andhra Pradesh' },
      { text: 'Arunachal Pradesh', value: 'Arunachal Pradesh' },
      { text: 'Assam', value: 'Assam' },
      { text: 'Bihar', value: 'Bihar' },
      { text: 'Chandigarh', value: 'Chandigarh' },
      { text: 'Chhattisgarh', value: 'Chhattisgarh' },
      { text: 'Dadra and Nagar Haveli', value: 'Dadra and Nagar Havelis' },
      { text: 'Daman and Diu', value: 'Daman and Diu' },
      { text: 'Delhi', value: 'Delhi' },
      { text: 'Goa', value: 'Goa' },
      { text: 'Gujarat', value: 'Gujarat' },
      { text: 'Haryana', value: 'Haryana' },
      { text: 'Himachal Pradesh', value: 'Himachal Pradesh' },
      { text: 'Jammu and Kashmir', value: 'Jammu and Kashmir' },
      { text: 'Jharkhand', value: 'Jharkhand' },
      { text: 'Karnataka', value: 'Karnataka' },
      { text: 'Kerala', value: 'Kerala' },
      { text: 'Lakshadweep', value: 'Lakshadweep' },
      { text: 'Madhya Pradesh', value: 'Madhya Pradesh' },
      { text: 'Maharashtra', value: 'Maharashtra' },
      { text: 'Manipur', value: 'Manipur' },
      { text: 'Meghalaya', value: 'Meghalaya' },
      { text: 'Mizoram', value: 'Mizoram' },
      { text: 'Nagaland', value: 'Nagaland' },
      { text: 'Odisha', value: 'Odisha' },
      { text: 'Puducherry', value: 'Puducherry' },
      { text: 'Punjab', value: 'Punjab' },
      { text: 'Rajasthan', value: 'Rajasthan' },
      { text: 'Sikkim', value: 'Sikkim' },
      { text: 'Tamil Nadu', value: 'Tamil Nadu' },
      { text: 'Telangana', value: 'Telangana' },
      { text: 'Tripura', value: 'Tripura' },
      { text: 'Uttar Pradesh', value: 'Uttar Pradesh' },
      { text: 'Uttarakhand', value: 'Uttarakhand' },
      { text: 'West Bengal', value: 'West Bengal' },
    ];
    /** Add New contact */
    this.addcustomerFormfromcheck = Formbuilder.group({
      'customername': [null, Validators.compose([Validators.required, Validators.pattern(this.alphawithdot), Validators.minLength(3), Validators.maxLength(40)])],
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'address': [null, Validators.compose([Validators.required])],
      'street': [null, Validators.compose([Validators.required])],
      'city': [null, Validators.compose([Validators.required])],
      'companytype': ["company", Validators.compose([Validators.required])],
      'zip': [null, Validators.compose([Validators.required, , Validators.pattern(this.zipvalidation)])],
      'gstin': [null, Validators.compose([Validators.required, Validators.pattern(this.alphanumeric), Validators.minLength(21), Validators.maxLength(21)])],
      'createdby': [null, Validators.compose([Validators.required])],
      'country': [null, Validators.compose([Validators.required])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.phonevalidation)])],
      'homestate': [null, Validators.compose([Validators.required])],
      'ibillaccount': [true],
      "appcode": [null]
      // 'createdbyname': ['superuser']
    });

    /** Check Availbality */
    this.verifycontactForm = Formbuilder.group({
      'customerusername': [null]
    });



    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
  }

  ngOnInit() {

    /** Get Customer */
    this.viewContact();
  }
  addcustomerform() {
    /** Add New contact */
    this.addcustomerForm = this.Formbuilder.group({
      'customername': [null, Validators.compose([Validators.required, Validators.pattern(this.alphawithdot), Validators.minLength(3), Validators.maxLength(40)])],
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'address': [null, Validators.compose([Validators.required])],
      'street': [null, Validators.compose([Validators.required])],
      'city': [null, Validators.compose([Validators.required])],
      'zip': [null, Validators.compose([Validators.required, , Validators.pattern(this.zipvalidation)])],
      'companytype': ["company", Validators.compose([Validators.required])],
      'gstin': [null, Validators.compose([Validators.required, Validators.pattern(this.alphanumeric), Validators.minLength(21), Validators.maxLength(21)])],
      'createdby': [this.userid],
      'country': [null, Validators.compose([Validators.required])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.phonevalidation)])],
      'homestate': [null, Validators.compose([Validators.required])],
      // 'createdbyname': ['superuser']
    });

  }

  /** Add New Contact */
  addContact() {
    this.addcustomerForm.value.phone = this.addcustomerForm.value.phone.toString();
    this.addcustomerForm.value.zip = this.addcustomerForm.value.zip.toString();
    var customerinfo = this.addcustomerForm.value;
    var appcode = this.appcode;
    var datatype = "customerinfo=" + JSON.stringify(customerinfo) + "&appcode=" + appcode;
    return this.makeapi.method(this.addCustomer, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            $("#addcontactModal").modal("hide");
            this.getdata.showNotification('bottom', 'right', 'Customer Added Successfully', "success");
            this.viewContact();
          } else if (data.isExists == true) {
            this.getdata.showNotification('bottom', 'right', 'Customer Already Exists', "success");
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {

        }
      );
  }

  /** View Contacts */
  viewContact() {
    var data = JSON.stringify({ "userid": this.userid });
    var appcode = this.appcode;
    var datatype = "userid=" + data + "&appcode=" + appcode;
    return this.makeapi.method(this.getCustomer, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          if (data.length > 0) {
            this.isData = 'true';
          } else {
            this.isData = 'false';
          }
          this.viewcustomerdata = data;
        },
        Error => {

        }
      );
  }

  /** Check Avaliablity of customer */
  verifyContact() {
    var customerusername = this.verifycontactForm.value.customerusername;
    // console.log(customerusername);
    var appcode = this.appcode;
    var datatype = "customerusername=" + customerusername + "&appcode=" + appcode;
    return this.makeapi.method(this.checkCustomerByAccount, datatype, 'post')
      .subscribe(
        data => {


          if (data.isExists == "false") {
            this.isCustomer = 'false';
            this.contactdetails = data.addressdetails;
            var getdata = this.addcustomerFormfromcheck.value;
            getdata.appcode = data.customerappcode;
            this.addcustomerFormfromcheck.patchValue(getdata);
            this.getdata.showNotification('bottom', 'right', 'Customer Not Available', "danger");
          }
          else {
            this.isCustomer = 'true';
            this.contactdetails = data.addressdetails;
            var getdata = this.addcustomerFormfromcheck.value;
            getdata.appcode = data.customerappcode;
            this.addcustomerFormfromcheck.patchValue(getdata);
          }
        },
        Error => {

        }
      );
  }
  gstindisplay: any;
  getcomptype(comptype) {
    if (comptype == "company") {
      this.addcustomerForm.get("gstin").enable();
      this.addcustomerForm.get('gstin').clearValidators();
      this.addcustomerForm.get('gstin').setValidators([Validators.required, Validators.pattern(this.alphanumeric), Validators.minLength(15), Validators.maxLength(15)]);
      this.addcustomerForm.get('gstin').updateValueAndValidity();
      this.gstindisplay = "block";
    }
    else {
      this.addcustomerForm.get('gstin').clearValidators();
      this.addcustomerForm.get('gstin').updateValueAndValidity();
      this.addcustomerForm.get("gstin").disable();
      this.gstindisplay = "none";
    }
  }
  // getcomptype(comptype) {
  //   if (comptype == "company") {
  //     this.addcustomerForm.get("gstin").enable();
  //   }
  //   else {
  //     this.addcustomerForm.get("gstin").disable();
  //     this.addcustomerForm.get("gstin").patchValue("");
  //   }
  // }
  getcomptypeedit(comptype) {
    if (comptype == "company") {
      this.editcustomerForm.get("gstin").enable();
    }
    else {
      this.editcustomerForm.get("gstin").disable();
      this.editcustomerForm.get("gstin").patchValue('');
    }
  }
  // addcheckContact() {
  //   var customerusername = this.verifycontactForm.value.customerusername;
  //   console.log(customerusername);
  //   var appcode = this.appcode;
  //   var datatype = "customerusername=" + customerusername + "&appcode=" + appcode;
  //   return this.makeapi.method(this.addCustomer, datatype, 'post')
  //     .subscribe(
  //       data => {
  //         this.contactdetails = data.addressdetails;
  //       },
  //       Error => {

  //       }
  //     );
  // }
  checkedobj = {};
  getcheckedcustomer(i) {
    // checkedobj[""]
    // this.checkedobj ={"customername":this.contactdetails[i],"email":"tryrtyrt","address":"tryrty","street":"rtyrtytryrty","city":"rtyrty","zip":"try","companytype":"company","gstin":"tryrt","state":"Tamil Nadu","createdby":"users6"};
    var getdata = this.addcustomerFormfromcheck.value;

    getdata.customername = this.contactdetails[i].companyname;
    getdata.email = this.contactdetails[i].email;
    getdata.address = this.contactdetails[i].address;
    getdata.street = this.contactdetails[i].street;

    getdata.city = this.contactdetails[i].city;
    getdata.zip = this.contactdetails[i].zip;
    getdata.companytype = this.contactdetails[i].companytype;
    getdata.createdby = this.contactdetails[i].createdby;

    getdata.country = this.contactdetails[i].country;
    getdata.phone = this.contactdetails[i].phone;
    getdata.homestate = this.contactdetails[i].homestate;

    if (this.contactdetails[i].gstin) {
      this.addcustomerForm.get("gstin").enable();
      getdata.gstin = this.contactdetails[i].gstin;
    }
    else {
      this.addcustomerForm.get("gstin").disable();
    }

    // console.log(getdata);

  }
  addContactcheck() {
    var customerinfo = this.addcustomerFormfromcheck.value;
    var appcode = this.appcode;
    var datatype = "customerinfo=" + JSON.stringify(customerinfo) + "&appcode=" + appcode;
    return this.makeapi.method(this.addCustomer, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            this.getdata.showNotification('bottom', 'right', 'Customer Added Successfully', "success");
            $("#verifycontactModal").modal("hide");
            this.viewContact();
          }
          else if (data.isExists == true) {
            this.getdata.showNotification('bottom', 'right', 'Customer Already Exist', "success");
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {

        }
      );
  }
  editcustomerid: any;
  seteditmodaldata(index) {
    this.editcustomerid = this.viewcustomerdata[index]._id
    var getdata = this.editcustomerForm.value;
    getdata.customername = this.viewcustomerdata[index].customername
    getdata.email = this.viewcustomerdata[index].email
    getdata.address = this.viewcustomerdata[index].address
    getdata.street = this.viewcustomerdata[index].street
    getdata.city = this.viewcustomerdata[index].city
    getdata.zip = this.viewcustomerdata[index].zip
    getdata.createdby = this.viewcustomerdata[index].createdby
    getdata.phone = this.viewcustomerdata[index].phone
    getdata.homestate = this.viewcustomerdata[index].homestate
    getdata.country = this.viewcustomerdata[index].country,
      this.editcustomerForm.patchValue(getdata);
  }
  editContact() {
    this.editcustomerForm.value.phone = this.editcustomerForm.value.phone.toString();
    this.editcustomerForm.value.zip = this.editcustomerForm.value.zip.toString();
    var data = JSON.stringify({ "userid": this.userid });
    var appcode = this.appcode;
    var datatype = "customerid=" + this.editcustomerid + "&appcode=" + appcode + "&obj=" + JSON.stringify(this.editcustomerForm.value);
    return this.makeapi.method(this.updateCustomer, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            this.getdata.showNotification('bottom', 'right', 'Customer Updated Successfully', "success");
            $("#editcontactModal").modal("hide");
            this.viewContact();
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {

        }
      );
  }
  deletebutton() {
    if (this.getcheckboxdelcon.length < 1) {
      this.getdata.showNotification('bottom', 'right', 'select Contact(s)', "danger");
    }
    else {
      $("#deletebulkconfirmation").modal("show");
    }
  }
  getcheckboxdelcon = [];
  getcuscheckbox() {
    var getcheckboxadditem = $('.cusclass:checked').map(function () {
      return $(this).val();
    }).get();
    this.getcheckboxdelcon = getcheckboxadditem;
    // console.log(this.getcheckboxdelcon);
  }

  getallcuscheckbox(ischecked) {
    if (ischecked == true) {
      $('.cusclass:checkbox').prop('checked', true);
      var getcheckboxcon = $('.cusclass:checked').map(function () {
        return $(this).val();
      }).get();
      this.getcheckboxdelcon = getcheckboxcon;
    }
    else {
      $('.cusclass:checkbox').prop('checked', false);
      this.getcheckboxdelcon = [];
    }

  }
  deletebulkcus() {
    let fimaldata = "appcode=" + this.appcode + "&customerid=" + JSON.stringify(this.getcheckboxdelcon);
    return this.makeapi.method(this.removeBulkCustomers, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Contact(s) Deleted Successfully.', 'success');
          this.viewContact();
          this.getcheckboxdelcon = [];
          $("#deletebulkconfirmation").modal("hide");
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }
  deletecontact() {
    let fimaldata = "appcode=" + this.appcode + "&customerid=" + this.editcustomerid;
    return this.makeapi.method(this.removeCustomer, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Contact Deleted Successfully.', 'success');
          this.viewContact();
          this.getcheckboxdelcon = [];
          $("#deletecontacts").modal("hide");
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }

  searchtable(inputid, tableid) {
    // Declare variables 
    var input, filter, table, tr, td, i;
    input = document.getElementById(inputid);
    filter = input.value.toUpperCase();
    table = document.getElementById(tableid);
    tr = table.getElementsByTagName("tr");

    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1];
      if (td) {
        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }
  cityvalidation() {
    if (this.addcustomerForm.value.city != null) {
      this.addcustomerForm.patchValue({ city: this.addcustomerForm.value.city.replace(/[^a-zA-Z]/g, '') });
    } else if (this.editcustomerForm.value.city != null) {
      this.editcustomerForm.patchValue({ city: this.editcustomerForm.value.city.replace(/[^a-zA-Z]/g, '') });
    }
  }

  /** Check Checkbox click for customer */
  checkOk(event) {
    console.log(event.target.checked);
    this.viewAdd = 'true';
  }

}

