import { NgModule } from '@angular/core';
import { routing } from "./contacts.routing";
import { CommonModule } from '@angular/common';
import { ContactsComponent } from './contacts.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { AbstractControl } from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@NgModule({
  imports: [routing,CommonModule, ReactiveFormsModule, NgSelectModule, FormsModule, NgxPaginationModule],
  declarations: [ContactsComponent]
})
export class ContactsModule {}