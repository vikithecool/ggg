import { Component, OnInit, Injectable, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthGuard } from '../canactivate.service';

declare var $: any;
declare var notes: any
@Component({
    selector: 'app-inventory',
    templateUrl: './inventory.component.html',
    styleUrls: ['./inventory.component.css']
})
export class InventoryComponent implements OnInit {
    getproductresponsedata: any;
    tableclass: any = "col-xl-12 col-lg-12 col-md-12 col-sm-12";
    isviewproductdetails: boolean = false;
    addproduct: FormGroup;
    changestock: FormGroup
    setprodid: any;
    setproductname: any;
    getaddedstocks: any;
    getupdatedstocks: any;
    gettransactions: any;
    isshowaddedstock: boolean = false;
    isshowupdatedstocks: boolean = false;
    isshowtransactions: boolean = false;
    numberpattern = /^[0-9]+$/;

    /** session       */
    appcode: any;
    userid: any;
    logintype: any;
    user_email: any;

    /** Is data */
    isData: any = 'false';

    private getProducts = this.getdata.appconstant + 'getProducts';
    private addstock = this.getdata.appconstant + 'addStock';
    private updatestock = this.getdata.appconstant + 'updateStock';

    p: number = 1;
    itemsPerPage: number = 8;

    constructor(private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {
        this.addproduct = Formbuilder.group({
            'stock': [null, Validators.compose([Validators.required, Validators.pattern(this.numberpattern), Validators.maxLength(10)])],

        });

        this.changestock = Formbuilder.group({
            'stock': [null, Validators.compose([Validators.required, Validators.pattern(this.numberpattern), Validators.maxLength(10)])],

        });
        this.appcode = this.getsession.session().appcode;
        this.userid = this.getsession.session().id;
        this.logintype = this.getsession.session().type;
        this.user_email = this.getsession.session().email;
        this.logintype = this.getsession.session().type;
    }

    ngOnInit() {
        this.getproducts();
    }
    getproducts() {
        let fimaldata = "appcode=" + this.appcode;
        return this.makeapi.method(this.getProducts, fimaldata, "post")
            .subscribe(data => {
                if (data.length > 0) {
                    this.isData = 'true';
                } else {
                    this.isData = 'false';
                }
                this.getproductresponsedata = data;
            },
                Error => {
                    alert('get products error');
                });
    }

    viewproductdetails(index) {
        this.isviewproductdetails = true;
        this.tableclass = "col-xl-6 col-lg-6 col-md-6 col-sm-12";
        this.getaddedstocks = this.getproductresponsedata[index].addedstocks;
        this.getupdatedstocks = this.getproductresponsedata[index].updatedstocks;

        this.gettransactions = this.getproductresponsedata[index].transactions

        // alert(this.getaddedstocks);
        // alert(this.getupdatedstocks);
        // alert(this.gettransactions);

        if (this.getaddedstocks == undefined) {
            this.isshowaddedstock = false;
        }
        else {
            this.isshowaddedstock = true;
        }
        if (this.getupdatedstocks == undefined) {
            this.isshowupdatedstocks = false;
        }
        else {
            this.isshowupdatedstocks = true;
        }
        if (this.gettransactions == undefined) {
            this.isshowtransactions = false;
        }
        else {
            this.isshowtransactions = true;
        }
    }
    changeStocks(updatetype) {
        let stockdata;
        if (updatetype == "add") {
            stockdata = JSON.stringify(this.addproduct.value);
        } else if (updatetype == "update") {
            stockdata = JSON.stringify(this.changestock.value);
        }
        let fimaldata = "appcode=" + this.appcode + "&prodobj=" + stockdata + "&prodid=" + this.setprodid + "&updatetype=" + updatetype;
        return this.makeapi.method(this.updatestock, fimaldata, "post")

            .subscribe(data => {
                if (data.status == "success") {
                    this.changestock.reset();
                    this.getproducts();
                    $("#changeproduct").modal("hide");
                    $("#addproduct").modal("hide");
                    this.getdata.showNotification('bottom', 'right', 'Stock Updated Successfully', "success");
                }
                else {
                    this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
                }
            },
                Error => {
                    this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
                });

    }
    deleteproduct(productid) {
        // let result = this.dialogService.confirm( 'Are you sure you want to delete this product?', 'No', 'Yes', '' );
        // // if you need both answers
        // result.subscribe(() => {
        //     const headers = new Headers();
        //     headers.append( 'Content-Type', 'application/x-www-form-urlencoded' );
        //     this.http.post( this.removeProduct, 'prodid=' + productid + "&appcode=" + this.finalsession.sessionappcode, { headers: headers } )
        //         .map(( response: Response ) => response.json() )
        //         .catch( this.errorhandle )
        //         .subscribe( data => {
        //             if ( data.status == "success" ) {
        //                 this.snackBar.open( "Product deleted successfully !", "Close", { duration: 3000 } );
        //                 this.ngOnInit();
        //             }
        //         },
        //         Error => {
        //             alert( 'remove product error' );
        //             this.errorMsg = Error;
        //         } );
        // },
        //     ( err: any ) => {
        //         // console.log('declined');
        //     }
        // );
    }

    allupdateChecked(event) {
        // this.demoChk = [];
        // var chname = document.getElementsByName( "productcheckbox" );
        // if ( event.target.checked ) {
        //     $( 'input:checkbox[name="productcheckbox"]' )
        //         .prop( 'checked', true );
        //     for ( var i = 0; i < chname.length; i++ ) {
        //         this.demoChk.push(( <any>chname[i] ).value );
        //     }
        // }
        // else {
        //     $( 'input:checkbox[name="productcheckbox"]' )
        //         .prop( 'checked', false );
        // }
        // console.log( this.demoChk )
    }
    updateChecked(value, event) {
        // if ( event.target.checked ) {
        //     this.demoChk.push( value );
        // }
        // else if ( !event.target.checked ) {
        //     let indexx = this.demoChk.indexOf( value );
        //     this.demoChk.splice( indexx, 1 );
        // }
        // console.log( this.demoChk )
    }

    searchproducttable() {
        //     var input, filter, table, tr, td, i, tdd;
        //     input = document.getElementById( "productsearchstr" );
        //     filter = input.value.toUpperCase();
        //     table = document.getElementById( "prodtableid" );
        //     tr = table.getElementsByTagName( "tr" );
        //     for ( i = 0; i < tr.length; i++ ) {
        //         td = tr[i].getElementsByTagName( "td" )[1];
        //         tdd = tr[i].getElementsByTagName( "td" )[0];
        //         if ( td || tdd ) {
        //             if ( td.innerHTML.toUpperCase().indexOf( filter ) > -1 || tdd.innerHTML.toUpperCase().indexOf( filter ) > -1 ) {
        //                 tr[i].style.display = "";
        //             }
        //             else {
        //                 tr[i].style.display = "none";
        //             }
        //         }
        //     }
        // }
    }
    setmodaldata(i) {
        this.addproduct.reset();
        this.changestock.reset();
        this.setprodid = this.getproductresponsedata[i]._id
        this.setproductname = this.getproductresponsedata[i].productname
    }
    searchtable(inputid, tableid) {
        // Declare variables 
        var input, filter, table, tr, td, i;
        input = document.getElementById(inputid);
        filter = input.value.toUpperCase();
        table = document.getElementById(tableid);
        tr = table.getElementsByTagName("tr");

        // Loop through all table rows, and hide those who don't match the search query
        for (i = 0; i < tr.length; i++) {
            td = tr[i].getElementsByTagName("td")[1];
            if (td) {
                if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
                    tr[i].style.display = "";
                } else {
                    tr[i].style.display = "none";
                }
            }
        }
    }

    routerUrl() {
        this.router.navigate(['dashboard/configuration']);
    }

}
