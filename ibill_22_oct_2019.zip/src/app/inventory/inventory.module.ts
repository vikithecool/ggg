import { NgModule } from '@angular/core';
import { routing } from "./inventory.routing";
import { ChartModule } from 'angular-highcharts';
import { CommonModule } from '@angular/common';
import { InventoryComponent } from './inventory.component';
import { ReactiveFormsModule } from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@NgModule({
  imports: [routing,ChartModule,CommonModule, ReactiveFormsModule, NgxPaginationModule],
  declarations: [InventoryComponent]
})
export class InventoryModule {}