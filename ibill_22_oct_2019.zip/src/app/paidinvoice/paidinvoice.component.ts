import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { Chart } from 'angular-highcharts';
import { AuthGuard } from '../canactivate.service';
declare var $: any;
@Component({
  selector: 'app-paidinvoice',
  templateUrl: './paidinvoice.component.html',
  styleUrls: ['./paidinvoice.component.css']
})
export class PaidinvoiceComponent implements OnInit {
  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;
  paiddata: any;

  /** Is data */
  isData: any = 'false';

  private getpaidinvoices = this.getdata.appconstant + 'getInvoicesByType';
  p: number = 1;
  itemsPerPage: number = 8;
  constructor(private getsession: AuthGuard, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {

    //   this.selectedproductname = "Select product to view transactions"
    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
  }

  ngOnInit() {

    this.getpaidinvoice();
  }
  getpaidinvoice() {
    let fimaldata = "appcode=" + this.appcode + "&type=paid";
    return this.makeapi.method(this.getpaidinvoices, fimaldata, "post")

      .subscribe(data => {
        if (data.length > 0) {
          this.isData = 'true';
        } else {
          this.isData = 'false';
        }
        this.paiddata = data;
      },
        Error => {
          alert('get invoice error');
        });
  }
  modaldata: any;
  viewalldetails: any;
  modaldatadetails: any;
  modalpayments: any;
  viewdetails(i) {
    this.modaldata = this.paiddata[i];
    this.modaldatadetails = this.paiddata[i].details;
    this.modalpayments = this.paiddata[i].payments;
  }

  routerUrl() {
    this.router.navigate(['dashboard/invoice']);
  }

}
