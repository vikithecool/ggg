import { NgModule  } from '@angular/core';
import { routing } from "./paidinvoice.routing";
import { PaidinvoiceComponent } from "./paidinvoice.component";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { AbstractControl } from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@NgModule({
  imports: [NgxPaginationModule,routing,FormsModule,ReactiveFormsModule,CommonModule,NgSelectModule],
  declarations: [PaidinvoiceComponent],
})
export class PaidinvoiceModule {}