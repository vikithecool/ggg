import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { Chart } from 'angular-highcharts';
declare var $: any;
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { AuthGuard } from '../canactivate.service';

@Component({
  selector: 'app-openinvoice',
  templateUrl: './openinvoice.component.html',
  styleUrls: ['./openinvoice.component.css']
})
export class OpeninvoiceComponent implements OnInit {
  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;
  generateddata: any;
  recordpaymentform: FormGroup;
  recordpaymentid: any;
  paymentamountdue: any;
  entermode: any;
  ismodeempty = true;
  p: number = 1;
  itemsPerPage: number = 8;

  /** Is data */
  isData: any = 'false';

  private getopeninvoices = this.getdata.appconstant + 'getInvoicesByType';
  private generateInvoice = this.getdata.appconstant + 'generateInvoice';
  private recordPayment = this.getdata.appconstant + 'recordPayment';

  emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  numbervalidation = /^[0-9,/]+$/;
  alphanumeric = /^[a-zA-Z0-9]+$/;
  alphawithdot = /^[a-zA-Z. ]+$/;
  decimalnumber = /^(0|[1-9]\d*)(\.\d+)?$/;
  alpha = /^[a-zA-Z]+$/;
  numbervalidation2 = /^[0-9]+$/;

  constructor(private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {

    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
  }

  ngOnInit() {
    this.recordpaymentformdata();
    this.getopeninvoice();
  }
  recordpaymentformdata() {
    this.recordpaymentform = this.Formbuilder.group({
      amountdue: ['', [Validators.required]],
      paymentamount: ['', [Validators.required, Validators.min(1)]],
      modeofpayment: ['', [Validators.required]],
      date: [new Date(), [Validators.required]],
      refno: ['', [Validators.required, Validators.pattern(this.alphawithdot)]],
    });
  }
  getopeninvoice() {
    let fimaldata = "appcode=" + this.appcode + "&type=generated";
    return this.makeapi.method(this.getopeninvoices, fimaldata, "post")

      .subscribe(data => {
        if (data.length > 0) {
          this.isData = 'true';
        } else {
          this.isData = 'false';
        }
        this.generateddata = data;
      },
        Error => {
          alert('get invoice error');
        });
  }

  generatepdf(index) {
    window.open(this.generateInvoice + "?appcode=" + this.appcode + "&invoiceid=" + this.generateddata[index]._id + "&userid=" + this.userid)
    // let fimaldata = "appcode=" + this.appcode + "&invoiceid=" + this.generateddata[index]._id + "&userid=" + this.userid;
    // return this.makeapi.method(this.generateInvoice, fimaldata, "post")
    //   .subscribe(data => {

    //   },
    //     Error => {
    //       alert('generate invoice error');
    //     });
  }

  setrecordid(index) {
    this.recordpaymentid = this.generateddata[index]._id;
    var getdata = this.recordpaymentform.value;
    getdata.amountdue = this.generateddata[index].amountdue;
    this.recordpaymentform.patchValue(getdata);
  }

  recordpayment() {
    var getdata = this.recordpaymentform.value;
    if (getdata.amountdue < getdata.paymentamount) {
      this.getdata.showNotification('bottom', 'right', 'Amount is greater than Amountdue', "danger");
      return false;
    }
    var date = this.recordpaymentform.value.date;
    var currentdate = date.getDate();
    var currentmonth = date.getMonth() + 1; // January is 0!
    var month = currentmonth;
    var currentyear = date.getFullYear();
    var finaldate;
    var finalmonth;
    if (currentdate < 10) {
      finaldate = '0' + currentdate;
    }
    else {
      finaldate = currentdate;
    }
    if (currentmonth < 10) {
      finalmonth = '0' + currentmonth;
    }
    else {
      finalmonth = currentmonth
    }
    var getdata = this.recordpaymentform.value;
    getdata.date = currentyear + "-" + finalmonth + "-" + finaldate;
    this.recordpaymentform.patchValue(getdata);
    let fimaldata = "appcode=" + this.appcode + "&invoiceid=" + this.recordpaymentid + "&userid=" + this.userid + "&payment=" + JSON.stringify(this.recordpaymentform.value);
    // console.log(fimaldata);
    return this.makeapi.method(this.recordPayment, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Payment Recorded Successfully', "success");
          $("#recordpayment").modal("hide");
          this.getopeninvoice();
          this.recordpaymentformdata();
          this.ismodeempty = true;

        }
        else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      },
        Error => {
          alert('Record Payment error');
        });
  }

  getmodeofpayment(event) {
    this.ismodeempty = false;

    if (event.target.value == "cash") {
      this.entermode = "Enter Cashier Name";
      this.recordpaymentform.get('refno').clearValidators();
      this.recordpaymentform.get('refno').setValidators([Validators.required, Validators.pattern(this.alphawithdot), Validators.minLength(3), Validators.maxLength(40)]);
      this.recordpaymentform.get('refno').updateValueAndValidity();
    } else if (event.target.value == "creditcard") {
      this.entermode = "Enter Credit card number";
      this.recordpaymentform.get('refno').clearValidators();
      this.recordpaymentform.get('refno').setValidators([Validators.required, Validators.pattern(this.numbervalidation2), Validators.maxLength(19)]);
      this.recordpaymentform.get('refno').updateValueAndValidity();
    } else if (event.target.value == "debitcard") {
      this.entermode = "Enter Debit card number";
      this.recordpaymentform.get('refno').clearValidators();
      this.recordpaymentform.get('refno').setValidators([Validators.required, Validators.pattern(this.numbervalidation2), Validators.maxLength(19)]);
      this.recordpaymentform.get('refno').updateValueAndValidity();
    } else if (event.target.value == "cheque") {
      this.entermode = "Enter Cheque number";
      this.recordpaymentform.get('refno').clearValidators();
      this.recordpaymentform.get('refno').setValidators([Validators.required, Validators.pattern(this.numbervalidation2), Validators.maxLength(10)]);
      this.recordpaymentform.get('refno').updateValueAndValidity();
    } else if (event.target.value == "online") {
      this.entermode = "Enter Online reference number";
      this.recordpaymentform.get('refno').clearValidators();
      this.recordpaymentform.get('refno').setValidators([Validators.required, Validators.pattern(this.alphanumeric), Validators.maxLength(20)]);
      this.recordpaymentform.get('refno').updateValueAndValidity();
    }
  }
  modaldata: any;
  viewalldetails: any;
  modaldatadetails: any;
  modalpayments: any;
  viewdetails(i) {
    this.modaldata = this.generateddata[i];
    this.modaldatadetails = this.generateddata[i].details;
    this.modalpayments = this.generateddata[i].payments;
  }

  routerUrl() {
    this.router.navigate(['dashboard/invoice']);
  }


}
