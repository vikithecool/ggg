import { NgModule  } from '@angular/core';
import { routing } from "./openinvoice.routing";
import { OpeninvoiceComponent } from "./openinvoice.component";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { AbstractControl } from '@angular/forms';
import { BsDatepickerModule } from 'ngx-bootstrap';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@NgModule({
  imports: [NgxPaginationModule,routing,FormsModule,ReactiveFormsModule,CommonModule,NgSelectModule,  BsDatepickerModule.forRoot()],
  declarations: [OpeninvoiceComponent],
})
export class OpeninvoiceModule {}