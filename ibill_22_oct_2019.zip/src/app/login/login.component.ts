import { Component, OnInit, Injectable, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  errormsg: any;
  loginform: FormGroup;
  private loginapi = this.getdata.appconstant + 'login';
  finalappcode: any;
  emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  numbervalidation = /^[0-9,/]+$/;
  alphanumeric = /^[a-zA-Z0-9]+$/;
  alphawithdot = /^[a-zA-Z. ]+$/;
  decimalnumber = /^(0|[1-9]\d*)(\.\d+)?$/;
  constructor(private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {
    this.loginform = Formbuilder.group({
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'password': [null, Validators.compose([Validators.required, Validators.minLength(8),])],
    });
  }

  ngOnInit() {
    this.session();
    if (this.session() != null && this.session().type == "organization") {
      this.router.navigateByUrl('/dashboard/home');
      return false;
    }
    else if (this.session() != null && this.session().type == "employee") {
      this.router.navigateByUrl('/dashboard/invoice');
      return false;
    }
    else if (this.session() != null && this.session().type == "client") {
      this.router.navigateByUrl('/dashboard/myinvoices');
      return false;
    }
    else {
      return true;
    }
  }
  session() {
    return JSON.parse(localStorage.getItem("sevinvoicesession"));
  }
  login() {
    let logindata = 'loginUser=' + JSON.stringify(this.loginform.value);
    return this.makeapi.method(this.loginapi, logindata, "post")
      .subscribe(data => {
        if (data.status == "success" && data.type == "organization") {
          localStorage.setItem("sevinvoicesession", JSON.stringify(data));
          this.router.navigateByUrl('/dashboard/home');
        }
        else if (data.status == "success" && data.type == "employee") {
          localStorage.setItem("sevinvoicesession", JSON.stringify(data));
          this.router.navigateByUrl('/dashboard/invoice');
        }
        else if (data.status == "success" && data.type == "client") {
          localStorage.setItem("sevinvoicesession", JSON.stringify(data));
          this.router.navigateByUrl('/dashboard/myinvoices');
        }
        else {
          this.errormsg = 'Invalid Username or Password';
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }
}
