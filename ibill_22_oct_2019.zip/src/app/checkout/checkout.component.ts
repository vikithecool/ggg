import { Component, OnInit, Pipe, PipeTransform, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { IfObservable } from 'rxjs/observable/IfObservable';
declare var $;
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/observable/of';
import { AuthGuard } from '../canactivate.service';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {

  /** session */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;

  constructor(private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http, private ref: ChangeDetectorRef) {
    // this.raiseInvoiceForm.get('invoice.discount').disable();
    if (this.getsession.session() == null) {
      this.router.navigateByUrl('/login');
    } else {
      this.appcode = this.getsession.session().appcode;
      this.userid = this.getsession.session().id;
      this.logintype = this.getsession.session().type;
      this.user_email = this.getsession.session().email;
      this.logintype = this.getsession.session().type;
    }


  }

  ngOnInit() {
  }

  logout() {
    localStorage.removeItem('sevinvoicesession');
    this.router.navigateByUrl('/login');
  }

}
