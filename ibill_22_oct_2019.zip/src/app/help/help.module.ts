import { NgModule } from '@angular/core';
import { routing } from "./help.routing";
import { ChartModule } from 'angular-highcharts';
import { HelpComponent } from './help.component';

@NgModule({
  imports: [routing,ChartModule],
  declarations: [HelpComponent]
})
export class HelpModule {}