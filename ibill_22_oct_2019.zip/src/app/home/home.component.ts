import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { Chart } from 'angular-highcharts';
import { AuthGuard } from '../canactivate.service';
declare var $;

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  first_widget: any;
  second_widget: any;
  third_widget: any;
  fourth_widget: any;
  sales = [];
  receipts = [];
  chart: any;
  salestype: any = 'monthwise';
  categorytype = [];
  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;

  /*** Declare */
  pending: any;
  completed: any;
  new: any;

  constructor(private getsession: AuthGuard, private getdata: DatatransferService, private router: Router, private makeapi: WebserviceService, private apiurl: DatatransferService, private http: Http) { }

  private getSalesReport = this.apiurl.appconstant + 'getSandOReport';
  private getDashboardCount = this.apiurl.appconstant + 'getDashboardInvCount';

  ngOnInit() {

    // this.raiseInvoiceForm.get('invoice.discount').disable();
    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.getsalesReport();
    this.getdashboardCount();

    // alert(this.apiurl.appconstant);
  }

  getsalesReport() {
    var datatype = "appcode=" + this.appcode + "&type=" + this.salestype;
    return this.makeapi.method(this.getSalesReport, datatype, "post")
      .subscribe(
        data => {
          for (var i = 0; i < data.sales.length; i++) {
            this.sales.push(data.sales[i].sales);
            this.receipts.push(data.sales[i].receipts);
            this.categorytype.push(data.sales[i].text)
          }

          this.first_widget = data.overdue.days0to15;
          this.second_widget = data.overdue.days15to30;
          this.third_widget = data.overdue.days30to45;
          this.fourth_widget = data.overdue.days45plus;

          // console.log(this.sales);
          this.chart = new Chart({
            chart: {
              type: 'column'
            },
            title: {
              text: ''
            },
            xAxis: {
              categories: this.categorytype
            },
            credits: {
              enabled: false
            },
            series: [{
              name: 'Sales',
              data: this.sales
            }, {
              name: 'Receipts',
              data: this.receipts
            }]
          });
        },
        Error => {
        });
  }

  getChartDetail(type) {
    if (type == 'quarterwise') {
      this.categorytype = []
    } else {
      this.categorytype = [];
    }
    this.salestype = type;
    this.sales = [];
    this.receipts = [];
    this.getsalesReport();
  }

  /** Get dashboard Count */
  getdashboardCount() {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.getDashboardCount, datatype, "post")
      .subscribe(
        data => {
          this.pending = data.expired;
          this.completed = data.paid;
          this.new = data.generated;
        },
        Error => {
        });
  }

}
