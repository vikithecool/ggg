import { Component } from '@angular/core';
import { DatatransferService } from './datatransfer.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';
  
  constructor(private getdata : DatatransferService) {
    this.getdata.getsession(JSON.parse(localStorage.getItem("sevinvoicesession")));
  }

}
