import { NgModule  } from '@angular/core';
import { routing } from "./overdue.routing";
import { OverdueComponent } from "./overdue.component";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { AbstractControl } from '@angular/forms';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@NgModule({
  imports: [routing,FormsModule,ReactiveFormsModule,CommonModule,NgSelectModule,NgxPaginationModule],
  declarations: [OverdueComponent],
})
export class OverdueModule {}