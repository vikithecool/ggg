import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { Chart } from 'angular-highcharts';
import { AuthGuard } from '../canactivate.service';
declare var $: any;

@Component({
  selector: 'app-overdue',
  templateUrl: './overdue.component.html',
  styleUrls: ['./overdue.component.css']
})
export class OverdueComponent implements OnInit {

  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;
  expireddata: any;
  p: number = 1;
  itemsPerPage: number = 8;

  /** Is data */
  isData: any = 'false';

  private getexpiredinvoices = this.getdata.appconstant + 'getExpiredInvoice';

  constructor(private getsession: AuthGuard, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {

    //   this.selectedproductname = "Select product to view transactions"
    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
  }

  ngOnInit() {
    this.getexpiredinvoice();
  }
  getexpiredinvoice() {
    let fimaldata = "appcode=" + this.appcode;
    return this.makeapi.method(this.getexpiredinvoices, fimaldata, "post")

      .subscribe(data => {
        if (data.length > 0) {
          this.isData = 'true';
        } else {
          this.isData = 'false';
        }
        this.expireddata = data;
      },
        Error => {
          alert('get invoice error');
        });
  }


  routerUrl() {
    this.router.navigate(['dashboard/invoice']);
  }

}
