import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule, BrowserXhr } from '@angular/http';
import { RouterModule } from '@angular/router';
import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';
import { CommonModule } from '@angular/common';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';
import { WebserviceService } from './webservice.service';
import { DatatransferService } from './datatransfer.service';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { NgSelectModule } from '@ng-select/ng-select';
import { ForgetpasswordComponent } from './forgetpassword/forgetpassword.component';
import { CanDeactivateGuard } from './deactivate.service';
import { InvoiceComponent } from './invoice/invoice.component';
import { AuthGuard } from './canactivate.service';
import { modalvaluetesting } from './modal.service';
import { NgxPaginationModule } from 'ngx-pagination';
import { CheckoutComponent } from './checkout/checkout.component'; // <-- import the module
import { SweetAlert2Module } from '@toverux/ngx-sweetalert2';

@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    LoginComponent,
    SignupComponent,
    ForgetpasswordComponent,
    InvoiceComponent,
    CheckoutComponent
  ],
  imports: [
    NgxPaginationModule,
    BrowserModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    RouterModule,
    AppRoutingModule,
    ComponentsModule,
    CommonModule,
    NgSelectModule,
    BsDatepickerModule.forRoot(),
    SweetAlert2Module.forRoot({
      buttonsStyling: false,
      customClass: 'modal-content',
      confirmButtonClass: 'btn btn-primary',
      cancelButtonClass: 'btn'
    })
  ],
  providers: [WebserviceService, DatatransferService, CanDeactivateGuard, AuthGuard, modalvaluetesting],
  bootstrap: [AppComponent]
})
export class AppModule { }
