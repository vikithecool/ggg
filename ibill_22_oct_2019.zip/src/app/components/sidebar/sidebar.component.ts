import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthGuard } from '../../canactivate.service';
import { DatatransferService } from '../../datatransfer.service';

declare const $: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
}
export const ROUTES: RouteInfo[] = [
    { path: 'home', title: 'Dashboard', icon: 'dashboard', class: '' },
    { path: 'upload', title: 'Upload File', icon: 'bubble_chart', class: '' },
    { path: 'settlement', title: 'Voucher Settlement', icon: 'content_paste', class: '' },
    { path: 'issuereport', title: 'Advance issued report', icon: 'library_books', class: '' },
    { path: '../login', title: 'Logout', icon: 'unarchive', class: 'active-pro' },
];

@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
    menuItems: any[];
    /** session       */
    appcode: any;
    userid: any;
    logintype: any;
    user_email: any;
    constructor(public router: Router, private getsession: AuthGuard, private getdata: DatatransferService) { }

    ngOnInit() {
        this.menuItems = ROUTES.filter(menuItem => menuItem);

        this.appcode = this.getsession.session().appcode;
        this.userid = this.getsession.session().id;
        this.logintype = this.getsession.session().type;
        this.user_email = this.getsession.session().email;
    }
    isMobileMenu() {
        if ($(window).width() > 991) {
            return false;
        }
        return true;
    };

    logout() {
        console.log('Logout Done!');
        localStorage.removeItem('user_id');
        this.router.navigateByUrl('/login');
    }

    /*** Get Router Lnk */
    getRouter(event) {
        var eventsplit = event.target.href.split('/');
        var eventHref = eventsplit[(eventsplit.length) - 1];
        this.getdata.showRouter(eventHref);
    }

}
