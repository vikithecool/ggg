import { Component, OnInit, Pipe, PipeTransform, ChangeDetectorRef } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../../webservice.service';
import { DatatransferService } from '../../datatransfer.service';
import 'rxjs/add/operator/map';
import { Subscription } from 'rxjs/Subscription';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { AuthGuard } from '../../canactivate.service';
import { modalvaluetesting } from '../../modal.service';
declare var $;

@Component({
  selector: 'app-modal',
  templateUrl: './modal.component.html',
  styleUrls: ['./modal.component.css']
})
export class ModalComponent implements OnInit {

  /** Add Contact */
  addcredentialForm: FormGroup;
  numberpattern = /^[0-9]+$/;

  /** Get All template */
  getAllDesignsTemp: any;
  selectedimageurl: any;
  selectedDesignid = 'design1';

  /** Add customer */
  addcustomerForm: FormGroup;

  /** Add Config */
  addconfigurationForm: FormGroup;

  /** Manage sales person  */
  managesalespersonForm: FormGroup;

  editcredentialForm: FormGroup;
  /** Get All states */

  /*** Is Customer */
  isCustomer: any = 'false';
  viewAdd: any = 'false';

  additemform: FormGroup;
  addcredentialFormclient: FormGroup;
  states: any;

  /** Uplaod File*/
  finallogofile: any;
  logofile: any;
  logoname: any;
  finallogofilesize: any;

  /** Payment Terms */
  items: FormArray;
  duetermsdata: any;
  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;

  /*logo upload */
  errormsgforlogoupload: any = 'false';

  /** Free User */
  lictype: any;
  freeUser: any = 'false';

  /** Template Rrquest */
  tempReq: any = 'false';

  /* validation */

  emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  numbervalidation = /^[0-9,/]+$/;
  alphanumeric = /^[a-zA-Z0-9]+$/;
  alphawithdot = /^[a-zA-Z. ]+$/;
  decimalnumber = /^(0|[1-9]\d*)(\.\d+)?$/;
  alpha = /^[a-zA-Z]+$/;
  zipvalidation = /^.{6,6}$/;
  phonevalidation = /^.{10,}$/;

  /** Choose template */
  template: any;
  customtemplate: any = 'false';

  /** Choose franchise */
  customfranchise: any = 'false';
  franchise: any;

  /**  */
  franchisetext: any;
  customtext: any;

  mytemplate: any;
  myfranchise: any;

  hsn = "HSN";

  constructor(private modaldatatesting: modalvaluetesting, private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {

    this.additemreactiveform();
    this.addconfigreactiveform();

    this.addcredentialform();
    this.addcustomerform();

    /** Manange sales person */
    this.managesalespersonForm = Formbuilder.group({
      items: Formbuilder.array([this.createsalesItem()]),
    });

    /** Get session data */

    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;

  }
  addcustomerform() {
    /** Add Customer */
    this.addcustomerForm = this.Formbuilder.group({
      'customername': [null, Validators.compose([Validators.required, Validators.pattern(this.alphawithdot), Validators.minLength(3), Validators.maxLength(40)])],
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.phonevalidation), Validators.minLength(10), Validators.maxLength(15)])],
      'address': [null, Validators.compose([Validators.required])],
      'street': [null, Validators.compose([Validators.required])],
      'city': [null, Validators.compose([Validators.required, Validators.pattern(this.alpha)])],
      'homestate': [null, Validators.compose([Validators.required])],
      'country': [],
      'zip': [null, Validators.compose([Validators.required, Validators.pattern(this.zipvalidation), Validators.minLength(6), Validators.maxLength(6)])],
      'gstin': [null, Validators.compose([Validators.required, Validators.pattern(this.alphanumeric), Validators.minLength(15), Validators.maxLength(15)])],
      'companytype': ["company", Validators.compose([Validators.required])],
      'createdby': [this.userid],
    });
  }
  additemreactiveform() {
    this.additemform = this.Formbuilder.group({
      'productname': [null, Validators.compose([Validators.required, Validators.maxLength(20), Validators.pattern(this.alphawithdot)])],
      'productprice': [null, Validators.compose([Validators.required, Validators.pattern(this.decimalnumber), Validators.maxLength(10)])],
      'producttype': ["goods", Validators.compose([Validators.required])],
      'gst': [null, Validators.compose([Validators.required])],
      'hsn': [null, Validators.compose([Validators.required, Validators.maxLength(8), Validators.pattern(this.numbervalidation)])],

    });
  }
  addconfigreactiveform() {
    /** Add Config */
    this.addconfigurationForm = this.Formbuilder.group({
      items: this.Formbuilder.array([this.createItem()]),
    });
  }
  addcredentialform() {
    /** Add Contact */
    this.addcredentialForm = this.Formbuilder.group({
      'companyname': [null, Validators.compose([Validators.required, Validators.pattern(this.alphawithdot), , Validators.minLength(3), Validators.maxLength(40)])],
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.phonevalidation), Validators.minLength(10), Validators.maxLength(15)])],
      'address': [null, Validators.compose([Validators.required])],
      'street': [null, Validators.compose([Validators.required])],
      'city': [null, Validators.compose([Validators.required, Validators.pattern(this.alpha)])],
      'homestate': [null, Validators.compose([Validators.required])],
      'country': [null, Validators.compose([Validators.required])],
      'zip': [null, Validators.compose([Validators.required, , Validators.pattern(this.zipvalidation), Validators.minLength(6), Validators.maxLength(6)])],
      'gstin': [null, Validators.compose([Validators.required, Validators.pattern(this.alphanumeric), Validators.minLength(15), Validators.maxLength(15)])],
      'cin': [null, Validators.compose([Validators.pattern(this.alphanumeric), Validators.minLength(21), Validators.maxLength(21)])],
      'labelprefix': [null, Validators.compose([Validators.pattern(this.alphanumeric)])],
      'nextnumber': [null, Validators.compose([Validators.required])],
      "logo": [null,],
      // "designname":['yellow']
    });


    this.addcredentialFormclient = this.Formbuilder.group({
      'companyname': [null, Validators.compose([Validators.required, Validators.pattern(this.alphawithdot), Validators.minLength(3), Validators.maxLength(40)])],
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.phonevalidation), Validators.minLength(10), Validators.maxLength(15)])],
      'address': [null, Validators.compose([Validators.required])],
      'street': [null, Validators.compose([Validators.required])],
      'city': [null, Validators.compose([Validators.required, Validators.pattern(this.alpha)])],
      'homestate': [null, Validators.compose([Validators.required])],
      'country': [null, Validators.compose([Validators.required])],
      'zip': [null, Validators.compose([Validators.required, Validators.pattern(this.zipvalidation), Validators.minLength(6), Validators.maxLength(6)])],
    });

  }
  private getAllDesigns = this.getdata.appconstant + 'getAllDesigns';
  private addSeller = this.getdata.appconstant + 'addSeller';
  private addCustomer = this.getdata.appconstant + 'addCustomer';
  private addDueTerm = this.getdata.appconstant + 'addDueTerm';
  private saveImage = this.getdata.appconstant + 'saveImage';
  private getDueTerms = this.getdata.appconstant + 'getDueTerms';
  private makeDefaultDueDate = this.getdata.appconstant + 'makeDefaultDueDate';
  private addProduct = this.getdata.appconstant + 'addProduct';
  private removeDueTerm = this.getdata.appconstant + 'removeDueTerm';
  private makeDefaultDueTerm = this.getdata.appconstant + 'makeDefaultDueTerm';
  private templateRequestApi = this.getdata.appconstant + 'templateRequestApi'

  verifycontactForm: FormGroup;
  ngOnInit() {
    this.modaldatatesting.displaydata.subscribe((data) => {
      if (data == "editSeller") {
        this.getInvoiceFromData();
      }
    });
    this.verifycontactForm = this.Formbuilder.group({
      'customerusername': [null]
    });
    $('#configurationModal2').on('hidden.bs.modal', () => {
      this.addconfigreactiveform();
      this.getdueterms();
    })
    $('#exampleModal2').on('hidden.bs.modal', () => {
      this.modaldatatesting.getmodalvalue("closesellermodal");
    })
    $('#customerModal2').on('hidden.bs.modal', () => {
      this.modaldatatesting.getmodalvalue("closescutomermodal");
    })
    $('#additemmodal').on('hidden.bs.modal', () => {
      this.modaldatatesting.getmodalvalue("closesitemmodal");
    })
    $('#configurationModal2').on('hidden.bs.modal', () => {
      this.modaldatatesting.getmodalvalue("closestermsmodal");
    })

    this.getAllDesignsfn();
    this.getdueterms();
    this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
      + "&designid=" + this.selectedDesignid;

    this.states = [
      { text: 'Andhra Pradesh', value: 'Andhra Pradesh' },
      { text: 'Arunachal Pradesh', value: 'Arunachal Pradesh' },
      { text: 'Assam', value: 'Assam' },
      { text: 'Bihar', value: 'Bihar' },
      { text: 'Chandigarh', value: 'Chandigarh' },
      { text: 'Chhattisgarh', value: 'Chhattisgarh' },
      { text: 'Dadra and Nagar Haveli', value: 'Dadra and Nagar Havelis' },
      { text: 'Daman and Diu', value: 'Daman and Diu' },
      { text: 'Delhi', value: 'Delhi' },
      { text: 'Goa', value: 'Goa' },
      { text: 'Gujarat', value: 'Gujarat' },
      { text: 'Haryana', value: 'Haryana' },
      { text: 'Himachal Pradesh', value: 'Himachal Pradesh' },
      { text: 'Jammu and Kashmir', value: 'Jammu and Kashmir' },
      { text: 'Jharkhand', value: 'Jharkhand' },
      { text: 'Karnataka', value: 'Karnataka' },
      { text: 'Kerala', value: 'Kerala' },
      { text: 'Lakshadweep', value: 'Lakshadweep' },
      { text: 'Madhya Pradesh', value: 'Madhya Pradesh' },
      { text: 'Maharashtra', value: 'Maharashtra' },
      { text: 'Manipur', value: 'Manipur' },
      { text: 'Meghalaya', value: 'Meghalaya' },
      { text: 'Mizoram', value: 'Mizoram' },
      { text: 'Nagaland', value: 'Nagaland' },
      { text: 'Odisha', value: 'Odisha' },
      { text: 'Puducherry', value: 'Puducherry' },
      { text: 'Punjab', value: 'Punjab' },
      { text: 'Rajasthan', value: 'Rajasthan' },
      { text: 'Sikkim', value: 'Sikkim' },
      { text: 'Tamil Nadu', value: 'Tamil Nadu' },
      { text: 'Telangana', value: 'Telangana' },
      { text: 'Tripura', value: 'Tripura' },
      { text: 'Uttar Pradesh', value: 'Uttar Pradesh' },
      { text: 'Uttarakhand', value: 'Uttarakhand' },
      { text: 'West Bengal', value: 'West Bengal' },
    ];
    /** Add New contact */
    this.addcustomerFormfromcheck = this.Formbuilder.group({
      'customername': [null, Validators.compose([Validators.required])],
      'email': [null, Validators.compose([Validators.required])],
      'address': [null, Validators.compose([Validators.required])],
      'street': [null, Validators.compose([Validators.required])],
      'city': [null, Validators.compose([Validators.required, Validators.pattern(this.alpha)])],
      'zip': [null, Validators.compose([Validators.required, Validators.pattern(this.zipvalidation), Validators.minLength(6), Validators.maxLength(6)])],
      'companytype': ["company", Validators.compose([Validators.required])],
      'gstin': [null, Validators.compose([Validators.required])],
      'createdby': [null, Validators.compose([Validators.required])],
      'country': [null, Validators.compose([Validators.required])],
      'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.phonevalidation)])],
      'homestate': [null, Validators.compose([Validators.required])],
      'ibillaccount': [true],
      "appcode": [null]
      // 'createdbyname': ['superuser']
    });

  }
  getprodtype(prodtype) {
    if (prodtype == "service") {
      this.hsn = "SAC"
    }
    else {
      this.hsn = "HSN"
    }
  }
  getcheckedcustomer(i) {
    // checkedobj[""]
    // this.checkedobj ={"customername":this.contactdetails[i],"email":"tryrtyrt","address":"tryrty","street":"rtyrtytryrty","city":"rtyrty","zip":"try","companytype":"company","gstin":"tryrt","state":"Tamil Nadu","createdby":"users6"};
    var getdata = this.addcustomerFormfromcheck.value;

    getdata.customername = this.contactdetails[i].companyname;
    getdata.email = this.contactdetails[i].email;
    getdata.address = this.contactdetails[i].address;
    getdata.street = this.contactdetails[i].street;

    getdata.city = this.contactdetails[i].city;
    getdata.zip = this.contactdetails[i].zip;
    getdata.companytype = this.contactdetails[i].companytype;
    getdata.createdby = this.contactdetails[i].createdby;

    getdata.country = this.contactdetails[i].country;
    getdata.phone = this.contactdetails[i].phone;
    getdata.homestate = this.contactdetails[i].homestate;

    if (this.contactdetails[i].gstin) {
      this.addcustomerForm.get("gstin").enable();
      getdata.gstin = this.contactdetails[i].gstin;
    }
    else {
      this.addcustomerForm.get("gstin").disable();
    }

    console.log(getdata);

  }
  get addconfigurationFormarray() { return <FormArray>this.addconfigurationForm.get('items') as FormArray }
  get managesalespersonformDataarray() { return <FormArray>this.managesalespersonForm.get('items') as FormArray }
  /** Check Avaliablity of customer */
  private checkCustomerByAccount = this.getdata.appconstant + 'checkCustomerByAccount';
  contactdetails: any;
  addcustomerFormfromcheck: any;

  verifyContact() {
    var customerusername = this.verifycontactForm.value.customerusername;
    console.log(customerusername);
    var appcode = this.appcode;
    var datatype = "customerusername=" + customerusername + "&appcode=" + appcode;
    return this.makeapi.method(this.checkCustomerByAccount, datatype, 'post')
      .subscribe(
        data => {


          if (data.isExists == "false") {
            this.isCustomer = 'false';
            this.getdata.showNotification('bottom', 'right', 'Customer Not Available', "danger");
          }
          else {
            this.isCustomer = 'true';
            this.contactdetails = data.addressdetails;
            var getdata = this.addcustomerFormfromcheck.value;
            getdata.appcode = data.customerappcode;
            this.addcustomerFormfromcheck.patchValue(getdata);
          }
        },
        Error => {

        }
      );
  }

  addContactcheck() {
    var customerinfo = this.addcustomerFormfromcheck.value;
    var appcode = this.appcode;
    var datatype = "customerinfo=" + JSON.stringify(customerinfo) + "&appcode=" + appcode;
    return this.makeapi.method(this.addCustomer, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            this.getdata.showNotification('bottom', 'right', 'Customer Added Successfully', "success");
            $("#verifycontactModal").modal("hide");
            this.modaldatatesting.getmodalvalue("addcustomer");
          }
          else if (data.isExists == true) {
            this.getdata.showNotification('bottom', 'right', 'Customer Already Exist', "success");
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {

        }
      );
  }
  closemodal() {

    $('#templateModal2').modal('hide');
    $('#exampleModal2').modal('show');
  }

  /** Get All Template */
  getAllDesignsfn() {
    var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getAllDesigns, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          this.getAllDesignsTemp = data;
        },
        Error => {

        }
      );
  }
  selectedDesignname: any;
  /** On change template */
  designchanged(event) {
    console.log(1);
    this.selectedDesignid = event.target.value.split("|")[0];
    this.selectedDesignname = event.target.value.split("|")[1];
    this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
      + "&designid=" + this.selectedDesignid;
    console.log(this.selectedimageurl);
  }

  /** Add new Contact on submit */
  addseller() {
    if (this.addcredentialForm.value.logo == null) {
      this.errormsgforlogoupload = 'true';
      return false;
    }
    if (this.addcredentialForm.valid) {

      this.addcredentialForm.get('logo').disable();
      this.addcredentialForm.value.phone = this.addcredentialForm.value.phone.toString();
      this.addcredentialForm.value.zip = this.addcredentialForm.value.zip.toString();
      if(this.tempReq == 'true') {
        this.addcredentialForm.value.custom = 'request';
      }
      this.addcredentialForm.value.nextnumber = Number(this.addcredentialForm.value.nextnumber);
      if (this.selectedDesignname == undefined) {
        this.addcredentialForm.value["designname"] = "yellow"; //Push default template key
      }
      else {
        this.addcredentialForm.value["designname"] = this.selectedDesignname; //Push default template key
      }
      if (this.customtemplate == 'true') {
        this.addcredentialForm.value["customtemplate"] = this.mytemplate; //Push default template key
      } else {

      }
      if (this.customfranchise == 'true') {
        this.addcredentialForm.value["franchisename"] = this.myfranchise; //Push default template key
      } else {

      }
      var datatype = "appcode=" + this.appcode + "&userid=" + this.userid + "&sellerobj=" + JSON.stringify(this.addcredentialForm.value);
      return this.makeapi.method(this.addSeller, datatype, 'post')
        .subscribe(
          data => {
            // console.log(data);
            // console.log('success');
            this.addcredentialForm.get('logo').enable();
            this.sendfile(data.sellerid);
            this.getInvoiceFromData();
          },
          Error => {
          }
        );
    } else {

    }
  }
  addsellerclient() {
    if (this.addcredentialFormclient.value.logo == null) {
      this.errormsgforlogoupload = 'true';
      return false;
    }
    if (this.addcredentialFormclient.valid) {

      this.addcredentialFormclient.get('logo').disable();
      this.addcredentialFormclient.value.phone = this.addcredentialFormclient.value.phone.toString();
      this.addcredentialFormclient.value.zip = this.addcredentialFormclient.value.zip.toString();
      if (this.selectedDesignname == undefined) {
        this.addcredentialFormclient.value["designname"] = "yellow"; //Push default template key
      }
      else {
        this.addcredentialFormclient.value["designname"] = this.selectedDesignname; //Push default template key
      }
      if (this.customtemplate == 'true') {
        this.addcredentialFormclient.value["customtemplate"] = this.mytemplate; //Push default template key
      } else {

      }
      if (this.customfranchise == 'true') {
        this.addcredentialFormclient.value["franchisename"] = this.myfranchise; //Push default template key
      } else {

      }
      var datatype = "appcode=" + this.appcode + "&userid=" + this.userid + "&sellerobj=" + JSON.stringify(this.addcredentialFormclient.value);
      return this.makeapi.method(this.addSeller, datatype, 'post')
        .subscribe(
          data => {
            // console.log(data);
            // console.log('success');
            $("#exampleModal2").modal("hide");
            this.addcredentialform();
            this.getInvoiceFromData();
            this.modaldatatesting.getmodalvalue("addseller");
          },
          Error => {
          }
        );
    } else {

    }
  }

  /** Add new Customer on submit */
  addcustomer() {
    if (this.addcustomerForm.valid) {
      this.addcustomerForm.value.phone = this.addcustomerForm.value.phone.toString();
      this.addcustomerForm.value.zip = this.addcustomerForm.value.zip.toString();
      this.addcustomerForm.value["createdby"] = this.userid; //Push default template key
      this.addcustomerForm.value["createdbyname"] = this.logintype; //Push default template key
      var datatype = "appcode=" + this.appcode + "&customerinfo=" + JSON.stringify(this.addcustomerForm.value);
      return this.makeapi.method(this.addCustomer, datatype, 'post')
        .subscribe(
          data => {
            if (data.status == "success") {
              this.getdata.showNotification('bottom', 'right', 'Customer Added Successfully', "success");
              $("#customerModal2").modal("hide");
              this.modaldatatesting.getmodalvalue("addcustomer");

            } else if (data.isExists == true) {
              this.getdata.showNotification('bottom', 'right', 'Customer Already Exist', "success");
            }
            else {
              this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
            }
          },
          Error => {

          }
        );
    } else {

    }
  }

  /** Add new Config on submit */
  addconfig() {
    if (this.addconfigurationForm.valid) {
      var getdata = this.addconfigurationForm.get('items').value;
      var datatype = "appcode=" + this.appcode + "&duetermobj=" + JSON.stringify(getdata);
      return this.makeapi.method(this.addDueTerm, datatype, 'post')
        .subscribe(
          data => {
            if (data.status == "success") {
              this.getdata.showNotification('bottom', 'right', 'Payment Terms Added Successfully', "success");
              $("#configurationModal2").modal("hide");
              this.modaldatatesting.getmodalvalue("adddueterm");
            }
            else {
              this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
            }
          },
          Error => {

          }
        );
    } else {

    }
  }

  /** Upload Logo */
  fileborder: any;
  getlogo(event) {
    let fileList: FileList = event.target.files;
    if (fileList.length > 0) {
      let file: File = fileList[0];
      this.logofile = file;
      this.logoname = file.name;

      var getdata = this.addcredentialForm.value;
      getdata.logo = file.name;
      this.addcredentialForm.patchValue(getdata);

      this.fileborder = "1px solid #009688"
      this.finallogofilesize = file.size / 1024 / 1024;
      if (this.finallogofilesize > 1) {
        // this.getsnackbar("Logo size must be less than 1MB", "red");
      }
      else {
        // let formData: FormData = new FormData();
        // formData.append('file', file);
        // this.logofile = formData;
      }

    }
  }

  /** File Upload */
  sendfile(sellerid) {
    let finalformdata: FormData = new FormData();
    finalformdata.append("file", this.logofile);
    finalformdata.append("filename", this.logoname);
    finalformdata.append("appcode", this.appcode);
    finalformdata.append("sellerid", sellerid);
    // alert(this.saveImage);
    return this.makeapi.method(this.saveImage, finalformdata, 'file')
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Seller Added Successfully', "success");
          $("#exampleModal2").modal("hide");
          this.logoname = "";
          this.addcredentialform();
          this.getInvoiceFromData();
          this.modaldatatesting.getmodalvalue("addseller");
        }
        else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      },
        Error => {
        });
  }
  /* add item */
  additemfinal() {
    this.additemform.value.gst = Number(this.additemform.value.gst);
    let fimaldata = "appcode=" + this.appcode + "&prodobj=" + JSON.stringify(this.additemform.value);
    return this.makeapi.method(this.addProduct, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Product Added Successfully.', 'success');
          this.modaldatatesting.getmodalvalue("additem");
          $("#additemmodal").modal("hide");
          this.additemreactiveform(); // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      },
        Error => {
          // alert( 'add stock error' );
        });
  }
  /** Get Due date */
  getduetermsdata: any;
  getdueterms() {
    var datatype = "appcode=" + this.appcode
    return this.makeapi.method(this.getDueTerms, datatype, 'post')
      .subscribe(
        data => {
          this.addconfigreactiveform();
          this.getduetermsdata = data;
          let control = this.addconfigurationForm.get('items') as FormArray;
          if (data.length > 0) {
            control.removeAt(0);
          }
          data.forEach(x => {

            control.push(this.Formbuilder.group({
              terms: x.terms,
              days: x.days
            }))
          })
        },
        Error => {

        }
      );
  }

  /** Make Due date default */
  makeDefault(i) {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.makeDefaultDueDate, datatype, 'post')
      .subscribe(
        data => {
          this.duetermsdata = data;
        },
        Error => {

        }
      );
  }
  addItem(): void {
    /** Add New Row */
    this.items = this.addconfigurationForm.get('items') as FormArray;
    this.items.push(this.createItem());
  }

  createItem(): FormGroup {
    return this.Formbuilder.group({
      // 'terms': [null, Validators.compose([Validators.required])],
      // 'days': [null, Validators.compose([Validators.required])],
      'terms': [null, Validators.compose([Validators.required])],
      'days': [null, Validators.compose([Validators.required])],
    });
  }

  /*** Manege sales person */
  createsalesItem(): FormGroup {
    return this.Formbuilder.group({
      'name': '',
      'email': ''
    });
  }
  gstindisplay = "block";
  getcomptype(comptype) {
    if (comptype == "company") {
      this.addcustomerForm.get("gstin").enable();
      this.addcustomerForm.get('gstin').clearValidators();
      this.addcustomerForm.get('gstin').setValidators([Validators.required, Validators.pattern(this.alphanumeric), Validators.minLength(15), Validators.maxLength(15)]);
      this.addcustomerForm.get('gstin').updateValueAndValidity();
      this.gstindisplay = "block";
    }
    else {
      this.addcustomerForm.get('gstin').clearValidators();
      this.addcustomerForm.get('gstin').updateValueAndValidity();
      this.addcustomerForm.get("gstin").disable();
      this.gstindisplay = "none";
    }
  }
  seteditmodaldatafinal(index, credentialdata) {
    $("#editcredentialmodal").modal("show")

    var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getSellers, datatype, 'post')
      .subscribe(
        data => {
          this.getCredentialsdata = data;
          // var getdata = this.editcredentialForm.value;
          // getdata.companyname = data[index].companyname;
          // getdata.email = data[index].email;
          // getdata.phone = data[index].phone;
          // getdata.address = data[index].address;
          // getdata.street = data[index].street;
          // getdata.city = data[index].city;
          // getdata.country = data[index].country;
          // getdata.zip = data[index].zip;
          // getdata.gstin = data[index].gstin;
          // getdata.cin = data[index].cin;
          // this.editcredentialForm.patchValue(getdata);
        },
        Error => {

        }
      )

  }
  getCredentialsdata: any;
  private getSellers = this.getdata.appconstant + 'getSellers';

  /** Get Invoice From or Seller Date */
  getInvoiceFromData() {
    var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getSellers, datatype, 'post')
      .subscribe(
        data => {
          if (this.lictype == 'free') {
            if (data.length > 0) {
              this.freeUser = 'true';
            } else {
              this.freeUser = 'false';
            }
          }
          this.getCredentialsdata = data;
        },
        Error => {

        }
      )
  }
  termDefault(i) {
    console.log(i)
    var datatype = "appcode=" + this.appcode + "&duetermid=" + this.getduetermsdata[i]._id;
    return this.makeapi.method(this.makeDefaultDueTerm, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            this.getdueterms();
            this.getdata.showNotification('bottom', 'right', 'Deafult Set Successfully', "success");
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }

        },
        Error => {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      )

  }
  deleteDefault(i) {
    var datatype = "appcode=" + this.appcode + "&duetermid=" + this.getduetermsdata[i]._id;
    return this.makeapi.method(this.removeDueTerm, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            this.getdueterms();
            this.modaldatatesting.getmodalvalue("adddueterm");
            this.getdata.showNotification('bottom', 'right', 'Payment Term Deleted Successfully', "success");
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      )

  }

  cityvalidation() {
    var getdata = this.addcredentialForm.value;
    // getdata.city = getdata.city.replace(/[^a-zA-Z]/g, '');
    if (this.addcredentialForm.value.city != null) {
      this.addcredentialForm.patchValue({ city: this.addcredentialForm.value.city.replace(/[^a-zA-Z]/g, '') });
    } else if (this.addcustomerForm.value.city != null) {
      this.addcustomerForm.patchValue({ city: this.addcustomerForm.value.city.replace(/[^a-zA-Z]/g, '') });
    }
  }
  numbervalidationkey() {
    var getdata = this.addcredentialForm.value;
    getdata.phone = getdata.phone.replace(/[^0-9]/g, '');
    this.addcredentialForm.patchValue(getdata);
  }
  alphanumericwithdotkey() {
    var getdata = this.addcredentialForm.value;
    getdata.key = getdata.key.replace(/[^a-zA-Z. ]/g, '');
    this.addcredentialForm.patchValue(getdata);
  }
  // emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  // numbervalidation = /^[0-9,/]+$/;
  // alphanumeric = /^[a-zA-Z0-9]+$/;
  // alphawithdot = /^[a-zA-Z. ]+$/;
  // decimalnumber = /^(0|[1-9]\d*)(\.\d+)?$/;
  // alpha = /^[a-zA-Z]+$/;


  /*** Choose template */
  chooseTemplate(event) {
    console.log(event.target.value);
    this.template = event.target.value;
    if (this.template == 'custom') {
      this.customtemplate = 'true';
    } else {
      this.customtemplate = 'false';
    }
  }

  /*** Choose template */
  chooseFranchise(event) {
    console.log(event.target.checked);
    this.franchise = event.target.checked;
    if (this.franchise == true) {
      this.customfranchise = 'true';
    } else {
      this.customfranchise = 'false';
    }
  }

  allowonlyletters(event) {
    console.log(event.target.value);
  }

  franchiseGettext(event) {
    this.myfranchise = event.target.value;
  }

  customGettext(event) {
    var k = event.keyCode;
    console.log(k);
    if (k == 32) return false;
    this.mytemplate = event.target.value;
  }

  onlyCharacterKey(event) {
    let charCode = (event.query) ? event.query : event.keyCode;
    console.log(charCode);
    if (charCode == 32) {
      return false;
    } else {
      return true;
    }
  }

  onlyNumberKey(event) {
    let charCode = (event.query) ? event.query : event.keyCode;
    console.log(charCode);
    if (charCode = 31
      && (charCode < 48 || charCode > 57))
      return false;

    return true;
  }

  numbervalidationNextkey() {
    var getdata = this.addcredentialForm.value;
    getdata.nextnumber = getdata.nextnumber.replace(/[^0-9]/g, '');
    this.addcredentialForm.patchValue(getdata);
  }

  /** Check Checkbox click for customer */
  checkOk(event) {
    console.log(event.target.checked);
    this.viewAdd = 'true';
  }

  /** Custom Template Request */
  templateRequest() {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.templateRequestApi, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            this.tempReq = 'true';
            this.getdata.showNotification('bottom', 'right', 'Mail Sent Successfully. We will contact you shortly', "success");
          }
          else {
            this.tempReq = 'true';
            this.getdata.showNotification('bottom', 'right', 'Mail Sent Successfully. We will contact you shortly', "success");
          }
        },
        Error => {
          this.tempReq = 'true';
          this.getdata.showNotification('bottom', 'right', 'Mail Sent Successfully. We will contact you shortly', "success");
          // this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      )
  }

}
