import { Component, OnInit, ElementRef, ViewChild } from '@angular/core';
import { ROUTES } from '../sidebar/sidebar.component';
import { Router, RouterModule } from '@angular/router';
import { Location, LocationStrategy, PathLocationStrategy } from '@angular/common';
import { DatatransferService } from '../../datatransfer.service';
import { WebserviceService } from '../../webservice.service';
import { ModalComponent } from '../modal/modal.component';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { AuthGuard } from '../../canactivate.service';
import { modalvaluetesting } from '../../modal.service';
declare var $: any;
@Component({
    selector: 'app-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.css'],
    providers: [ModalComponent]
})
export class NavbarComponent implements OnInit {
    private listTitles: any[];
    location: Location;
    private toggleButton: any;
    private sidebarVisible: boolean;
    getCredentialsdata: any;
    /** session       */
    appcode: any;
    userid: any;
    logintype: any;
    user_email: any;
    selectedimageurl: any;
    selectedDesignid: any = "design1";
    franchise: any;
    customfranchise: any = 'false';
    template: any;
    customtemplate: any = 'false';
    editsellerForm: FormGroup;
    states: any;
    mytemplate: any;
    getAllDesignsTemp: any;
    designname: any;
    selectedDesignname: any;

    /*logo upload */
    errormsgforlogoupload: any = 'false';

    /** Uplaod File*/
    finallogofile: any;
    logofile: any;
    logoname: any;
    finallogofilesize: any;
    lictype: any;
    freeUser: any = 'false';

    private getSellers = this.getdata.appconstant + 'getSellers';
    private updateSeller = this.getdata.appconstant + 'updateSeller';
    private setDefaultCredential = this.getdata.appconstant + 'setDefaultSeller';
    private removeSeller = this.getdata.appconstant + 'removeSeller';
    private getAllDesigns = this.getdata.appconstant + 'getAllDesigns';
    private saveImage = this.getdata.appconstant + 'saveImage';
    private templateRequestApi = this.getdata.appconstant + 'templateRequestApi';


    emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    numbervalidation = /^[0-9,/]+$/;
    alphanumeric = /^[a-zA-Z0-9]+$/;
    alphawithdot = /^[a-zA-Z. ]+$/;
    decimalnumber = /^(0|[1-9]\d*)(\.\d+)?$/;
    alpha = /^[a-zA-Z]+$/;
    zipvalidation = /^.{6,6}$/;

    constructor(private modaldatatesting: modalvaluetesting, private getsession: AuthGuard, private Formbuilder: FormBuilder, private ModalComponent: ModalComponent, private makeapi: WebserviceService, location: Location, private element: ElementRef, public router: Router, private getdata: DatatransferService) {
        this.location = location;
        this.sidebarVisible = false;

        /* edit form */
        this.editsellerForm = Formbuilder.group({
            'companyname': [null, Validators.compose([Validators.required, Validators.minLength(3), Validators.maxLength(40)])],
            'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
            'phone': [null, Validators.compose([Validators.required, Validators.pattern(this.numbervalidation), Validators.minLength(10), Validators.maxLength(15)])],
            'address': [null, Validators.compose([Validators.required])],
            'street': [null, Validators.compose([Validators.required])],
            'city': [null, Validators.compose([Validators.required, Validators.pattern(this.alpha)])],
            'homestate': [null, Validators.compose([Validators.required])],
            'country': [null],
            'zip': [null, Validators.compose([Validators.required, , Validators.pattern(this.zipvalidation)])],
            'gstin': [null, Validators.compose([Validators.required, Validators.pattern(this.alphanumeric), Validators.minLength(15), Validators.maxLength(15)])],
            'cin': [null, Validators.compose([Validators.pattern(this.alphanumeric), Validators.minLength(21), Validators.maxLength(21)])],
            'nextnumber': [null, Validators.compose([Validators.required])],
            'labelprefix': [null, Validators.compose([Validators.pattern(this.alphanumeric)])],
            "logo": [null,],
            "customtemplate": [null],
            "franchisename": [null],
        });

    }

    ngOnInit() {
        this.listTitles = ROUTES.filter(listTitle => listTitle);
        const navbar: HTMLElement = this.element.nativeElement;
        this.toggleButton = navbar.getElementsByClassName('navbar-toggle')[0];

        this.appcode = this.getsession.session().appcode;
        this.userid = this.getsession.session().id;
        this.logintype = this.getsession.session().type;
        this.user_email = this.getsession.session().email;
        this.lictype = this.getsession.session().lictype;
        this.getInvoiceFromData();
        this.modaldatatesting.displaydata.subscribe((data) => {
            if (data == "addseller") {
                this.getInvoiceFromData();
            }
        })
        this.states = [
            { text: 'Andhra Pradesh', value: 'Andhra Pradesh' },
            { text: 'Arunachal Pradesh', value: 'Arunachal Pradesh' },
            { text: 'Assam', value: 'Assam' },
            { text: 'Bihar', value: 'Bihar' },
            { text: 'Chandigarh', value: 'Chandigarh' },
            { text: 'Chhattisgarh', value: 'Chhattisgarh' },
            { text: 'Dadra and Nagar Haveli', value: 'Dadra and Nagar Havelis' },
            { text: 'Daman and Diu', value: 'Daman and Diu' },
            { text: 'Delhi', value: 'Delhi' },
            { text: 'Goa', value: 'Goa' },
            { text: 'Gujarat', value: 'Gujarat' },
            { text: 'Haryana', value: 'Haryana' },
            { text: 'Himachal Pradesh', value: 'Himachal Pradesh' },
            { text: 'Jammu and Kashmir', value: 'Jammu and Kashmir' },
            { text: 'Jharkhand', value: 'Jharkhand' },
            { text: 'Karnataka', value: 'Karnataka' },
            { text: 'Kerala', value: 'Kerala' },
            { text: 'Lakshadweep', value: 'Lakshadweep' },
            { text: 'Madhya Pradesh', value: 'Madhya Pradesh' },
            { text: 'Maharashtra', value: 'Maharashtra' },
            { text: 'Manipur', value: 'Manipur' },
            { text: 'Meghalaya', value: 'Meghalaya' },
            { text: 'Mizoram', value: 'Mizoram' },
            { text: 'Nagaland', value: 'Nagaland' },
            { text: 'Odisha', value: 'Odisha' },
            { text: 'Puducherry', value: 'Puducherry' },
            { text: 'Punjab', value: 'Punjab' },
            { text: 'Rajasthan', value: 'Rajasthan' },
            { text: 'Sikkim', value: 'Sikkim' },
            { text: 'Tamil Nadu', value: 'Tamil Nadu' },
            { text: 'Telangana', value: 'Telangana' },
            { text: 'Tripura', value: 'Tripura' },
            { text: 'Uttar Pradesh', value: 'Uttar Pradesh' },
            { text: 'Uttarakhand', value: 'Uttarakhand' },
            { text: 'West Bengal', value: 'West Bengal' },


        ];
        this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
            + "&designid=" + this.selectedDesignid;
        this.getAllDesignsfn();
        this.checkNewUser();
    }

    /*** Check New user */
    checkNewUser() {
        var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
        return this.makeapi.method(this.getSellers, datatype, 'post')
            .subscribe(
                data => {
                    if (data.length > 0) {

                    } else {
                        $('#exampleModal2').modal('show');
                    }
                },
                Error => {

                }
            )
    }

    sidebarOpen() {
        const toggleButton = this.toggleButton;
        const body = document.getElementsByTagName('body')[0];
        setTimeout(function () {
            toggleButton.classList.add('toggled');
        }, 500);
        body.classList.add('nav-open');

        this.sidebarVisible = true;
    };
    sidebarClose() {
        const body = document.getElementsByTagName('body')[0];
        this.toggleButton.classList.remove('toggled');
        this.sidebarVisible = false;
        body.classList.remove('nav-open');
    };
    sidebarToggle() {
        // const toggleButton = this.toggleButton;
        // const body = document.getElementsByTagName('body')[0];
        if (this.sidebarVisible === false) {
            this.sidebarOpen();
        } else {
            this.sidebarClose();
        }
    };

    getTitle() {
        var titlee = this.location.prepareExternalUrl(this.location.path());
        if (titlee.charAt(0) === '#') {
            titlee = titlee.slice(2);
        }
        titlee = titlee.split('/').pop();

        for (var item = 0; item < this.listTitles.length; item++) {
            if (this.listTitles[item].path === titlee) {
                return this.listTitles[item].title;
            }
        }
        return 'Dashboard';
    }
    logout() {
        localStorage.removeItem('sevinvoicesession');
    }
    openNav() {
        document.getElementById("mySidenav").style.width = "250px";
    }

    closeNav() {
        document.getElementById("mySidenav").style.width = "0";
    }
    /** Get Invoice From or Seller Date */
    getInvoiceFromData() {
        var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
        return this.makeapi.method(this.getSellers, datatype, 'post')
            .subscribe(
                data => {
                    if (this.lictype == 'free') {
                        if (data.length > 0) {
                            this.freeUser = 'true';
                        } else {
                            this.freeUser = 'false';
                        }
                    }
                    this.getCredentialsdata = data;
                },
                Error => {

                }
            )
    }
    sellerid: any;
    seteditmodaldata(index) {
        this.logofile = null;
        this.logoname = null;
        this.customfranchise = 'false';
        $('.form-check-input').prop('checked', false);

        this.sellerid = this.getCredentialsdata[index]._id;
        $("#editcredentialmodal").modal("show");
        var getdata = this.editsellerForm.value;
        getdata.companyname = this.getCredentialsdata[index].companyname;
        getdata.email = this.getCredentialsdata[index].email;
        getdata.phone = this.getCredentialsdata[index].phone;
        getdata.address = this.getCredentialsdata[index].address;
        getdata.street = this.getCredentialsdata[index].street;
        getdata.city = this.getCredentialsdata[index].city;
        getdata.country = this.getCredentialsdata[index].country;
        getdata.zip = this.getCredentialsdata[index].zip;
        getdata.gstin = this.getCredentialsdata[index].gstin;
        getdata.cin = this.getCredentialsdata[index].cin;
        getdata.homestate = this.getCredentialsdata[index].homestate;
        getdata.nextnumber = this.getCredentialsdata[index].nextnumber;
        getdata.labelprefix = this.getCredentialsdata[index].labelprefix;
        if ((this.getCredentialsdata[index].customtemplate != undefined)) {
            this.customtemplate = 'true';
            $('.custom').prop('checked', true);
            getdata.customtemplate = this.getCredentialsdata[index].customtemplate;
        }
        else {
            this.customtemplate = 'false';
            $('.default').prop('checked', true);
        }
        if ((this.getCredentialsdata[index].franchisename != undefined)) {
            this.customfranchise = 'true';
            $('.form-check-input').prop('checked', true);
            getdata.franchisename = this.getCredentialsdata[index].franchisename;
            console.log(this.getCredentialsdata[index].designname)
        }
        else {
            this.customtemplate = 'false';
            $('.default').prop('checked', true);
        }
        if (this.getCredentialsdata[index].designname == "yellow") {
            this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
                + "&designid=" + 'design1';
            this.selectedDesignname = 'yellow';
        }
        if (this.getCredentialsdata[index].designname == "cyan") {
            this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
                + "&designid=" + "design5";
            this.selectedDesignname = 'cyan';
        }
        if (this.getCredentialsdata[index].designname == "skyblue") {
            this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
                + "&designid=" + "design2";
            this.selectedDesignname = 'skyblue';
        }
        if (this.getCredentialsdata[index].designname == "pink") {
            this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
                + "&designid=" + "design3";
            this.selectedDesignname = 'pink';
        }
        if (this.getCredentialsdata[index].designname == "green") {
            this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
                + "&designid=" + "design4";
            this.selectedDesignname = 'green';
        }

        this.editsellerForm.patchValue(getdata);
        // this.ModalComponent.seteditmodaldatafinal(index , this.getCredentialsdata);
    }
    editseller() {
        if (this.editsellerForm.value.logo == null) {
            this.errormsgforlogoupload = 'true';
            return false;
        }
        if (this.editsellerForm.valid) {

            this.editsellerForm.get('logo').disable();
            // alert(typeof  this.editsellerForm.value.phone )
            if (this.customfranchise == 'false') {
                delete this.editsellerForm.value.franchisename
            }
            if (this.customtemplate == 'false') {
                delete this.editsellerForm.value.customtemplate
            }
            this.editsellerForm.value["designname"] = this.selectedDesignname; //Push default template key

            this.editsellerForm.value.phone = this.editsellerForm.value.phone.toString();
            this.editsellerForm.value.zip = this.editsellerForm.value.zip.toString();
            // alert(typeof  this.editsellerForm.value.phone )
            var datatype = "appcode=" + this.appcode + "&sellerid=" + this.sellerid + "&obj=" + JSON.stringify(this.editsellerForm.value);
            return this.makeapi.method(this.updateSeller, datatype, 'post')
                .subscribe(
                    data => {
                        if (data.status == "success") {
                            this.getdata.showNotification('bottom', 'right', 'Seller Updated Successfully', "success");
                            $("#editcredentialmodal").modal("hide");
                            this.modaldatatesting.getmodalvalue("editSeller");
                            this.getInvoiceFromData();
                            this.editsellerForm.get('logo').enable();
                            this.sendfile(data.sellerid);
                            this.errormsgforlogoupload = 'false';
                        }
                        else {
                            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
                        }
                    },
                    Error => {
                        this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");

                    }
                )
        }
    }
    setdefault(id, companyname) {
        var datatype = "appcode=" + this.appcode + "&sellerid=" + id;
        return this.makeapi.method(this.setDefaultCredential, datatype, 'post')
            .subscribe(
                data => {
                    if (data.status == "success") {
                        this.getdata.showNotification('bottom', 'right', 'Default Organisation changed to ' + companyname, "success");
                        this.getInvoiceFromData();
                        this.modaldatatesting.getmodalvalue("addseller");
                    }
                    else {
                        this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
                    }
                },
                Error => {
                    this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");

                }
            )
    }
    setsellerid(id) {
        this.sellerid = id;
    }
    deleteseller() {
        var datatype = "appcode=" + this.appcode + "&sellerid=" + this.sellerid;
        return this.makeapi.method(this.removeSeller, datatype, 'post')
            .subscribe(
                data => {
                    if (data.status == "success") {
                        this.modaldatatesting.getmodalvalue("addseller");
                        this.getInvoiceFromData();
                        this.getdata.showNotification('bottom', 'right', 'Seller Deleted Successfully', "success");
                        $("#deleteconfirmation").modal("hide");
                    }
                    else {
                        this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
                    }
                },
                Error => {

                }
            )
    }
    cityvalidation() {
        if (this.editsellerForm.value.city != null) {
            this.editsellerForm.patchValue({ city: this.editsellerForm.value.city.replace(/[^a-zA-Z]/g, '') });
        }
    }

    chooseFranchise(event) {
        console.log(event.target.checked);
        this.franchise = event.target.checked;
        if (this.franchise == true) {
            this.customfranchise = 'true';
        } else {
            this.customfranchise = 'false';
        }
    }
    chooseTemplate(event) {
        console.log(event.target.value);
        this.template = event.target.value;
        if (this.template == 'custom') {
            this.customtemplate = 'true';
        } else {
            this.customtemplate = 'false';
        }
    }

    customGettext(event) {
        var k = event.keyCode;
        if (k == 32) return false;
    }
    onlyCharacterKey(event) {
        let charCode = (event.query) ? event.query : event.keyCode;
        if (charCode == 32) {
            return false;
        } else {
            return true;
        }
    }

    /** Get All Template */
    getAllDesignsfn() {
        var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
        return this.makeapi.method(this.getAllDesigns, datatype, 'post')
            .subscribe(
                data => {
                    // console.log(data);
                    this.getAllDesignsTemp = data;
                },
                Error => {

                }
            );
    }
    /** On change template */
    designchanged(event) {
        this.selectedDesignid = event.target.value.split("|")[0];
        this.selectedDesignname = event.target.value.split("|")[1];
        this.selectedimageurl = this.getdata.appconstant + "getDesignImage?appcode=" + this.appcode
            + "&designid=" + this.selectedDesignid;
    }
    /** Upload Logo */
    fileborder: any;
    getlogo(event) {
        let fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            let file: File = fileList[0];
            this.logofile = file;
            this.logoname = file.name;

            var getdata = this.editsellerForm.value;
            getdata.logo = file.name;
            this.editsellerForm.patchValue(getdata);

            this.fileborder = "1px solid #009688"
            this.finallogofilesize = file.size / 1024 / 1024;
            if (this.finallogofilesize > 1) {
                // this.getsnackbar("Logo size must be less than 1MB", "red");
            }
            else {
                // let formData: FormData = new FormData();
                // formData.append('file', file);
                // this.logofile = formData;
            }

        }
    }
    /** File Upload */
    sendfile(sellerid) {
        let finalformdata: FormData = new FormData();
        finalformdata.append("file", this.logofile);
        finalformdata.append("filename", this.logoname);
        finalformdata.append("appcode", this.appcode);
        finalformdata.append("sellerid", sellerid);
        // alert(this.saveImage);
        return this.makeapi.method(this.saveImage, finalformdata, 'file')
            .subscribe(data => {
                if (data.status == "success") {
                    this.getdata.showNotification('bottom', 'right', 'Seller Added Successfully', "success");
                    this.logoname = "";
                    this.getInvoiceFromData();
                    this.modaldatatesting.getmodalvalue("addseller");
                }
                else {
                    this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
                }
            },
                Error => {
                });
    }

    /** Add New Contact */
    fromaddrchanged() {
        var ask = confirm('Upgrade to Pro');
        if (ask) {
            this.router.navigateByUrl('/checkout');
        }
    }

    upgrade() {
        this.router.navigate(['checkout']);
    }

    /** Custom Template Request */
    templateRequest() {
        var datatype = "appcode=" + this.appcode;
        return this.makeapi.method(this.templateRequestApi, datatype, 'post')
            .subscribe(
                data => {
                    if (data.status == "success") {
                        this.getdata.showNotification('bottom', 'right', 'Mail Sent Successfully. We will contact you shortly', "success");
                    }
                    else {
                        this.getdata.showNotification('bottom', 'right', 'Mail Sent Successfully. We will contact you shortly', "success");
                    }
                },
                Error => {
                    this.getdata.showNotification('bottom', 'right', 'Mail Sent Successfully. We will contact you shortly', "success");
                    // this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
                }
            )
    }

}