import { NgModule } from '@angular/core';
import { CommonModule, } from '@angular/common';
import { BrowserModule } from '@angular/platform-browser';
import { Routes, RouterModule, ActivatedRouteSnapshot, RouterStateSnapshot } from '@angular/router';
import { CheckoutComponent } from './checkout/checkout.component';
import { LoginComponent } from './login/login.component';
import { SignupComponent } from './signup/signup.component';
import { ForgetpasswordComponent } from './forgetpassword/forgetpassword.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { CanDeactivateGuard } from './deactivate.service';
import { InvoiceComponent } from './invoice/invoice.component';
import { AuthGuard } from './canactivate.service';

const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'login' },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'checkout', component: CheckoutComponent },
  { path: 'forgetpassword', component: ForgetpasswordComponent },
  {
    path: 'dashboard', component: DashboardComponent, canDeactivate: [CanDeactivateGuard],
    children: [
      { path: '', redirectTo: 'home', pathMatch: 'full' },
      { path: 'home', loadChildren: 'app/home/home.module#HomeModule', canActivate: [AuthGuard] },
      { path: 'invoice', component: InvoiceComponent, canDeactivate: [CanDeactivateGuard], canActivate: [AuthGuard] },
      // { path: 'invoice', loadChildren: 'app/invoice/invoice.module#InvoiceModule' },
      { path: 'openinvoice', loadChildren: 'app/openinvoice/openinvoice.module#OpeninvoiceModule', canActivate: [AuthGuard] },
      { path: 'paidinvoice', loadChildren: 'app/paidinvoice/paidinvoice.module#PaidinvoiceModule', canActivate: [AuthGuard] },
      { path: 'overdue', loadChildren: 'app/overdue/overdue.module#OverdueModule', canActivate: [AuthGuard] },
      { path: 'help', loadChildren: 'app/help/help.module#HelpModule', canActivate: [AuthGuard] },
      { path: 'myinvoices', loadChildren: 'app/myinvoices/myinvoices.module#MyinvoicesModule', canActivate: [AuthGuard] },
      { path: 'inventory', loadChildren: 'app/inventory/inventory.module#InventoryModule', canActivate: [AuthGuard] },
      { path: 'configuration', loadChildren: 'app/configuration/configuration.module#ConfigurationModule', canActivate: [AuthGuard] },
      { path: 'contacts', loadChildren: 'app/contacts/contacts.module#ContactsModule', canActivate: [AuthGuard] },
      { path: 'estimate', loadChildren: 'app/estimate/estimate.module#EstimateModule', canActivate: [AuthGuard] },
      { path: 'viewestimate', loadChildren: 'app/viewestimates/viewestimates.module#ViewestimateModule', canActivate: [AuthGuard] },
      { path: 'items', loadChildren: 'app/items/items.module#ItemsModule', canActivate: [AuthGuard] }
    ]
  },
];

@NgModule({
  imports: [
    CommonModule,
    BrowserModule,
    RouterModule.forRoot(routes, { useHash: true })
  ],
  exports: [
    RouterModule,
  ],
})
export class AppRoutingModule { }
