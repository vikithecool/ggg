import { Component, OnInit, Injectable, ChangeDetectorRef, ViewChild } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { FormBuilder, FormGroup, Validators, FormArray } from '@angular/forms';
import { isArray } from 'util';
import { AuthGuard } from '../canactivate.service';
declare var $;

@Component({
  selector: 'app-items',
  templateUrl: './items.component.html',
  styleUrls: ['./items.component.css']
})
export class ItemsComponent implements OnInit {

  private getProducts = this.getdata.appconstant + 'getProducts';
  private addProduct = this.getdata.appconstant + 'addProduct';
  private updateProduct = this.getdata.appconstant + 'updateProduct';
  private removeBulkProducts = this.getdata.appconstant + 'removeBulkProducts';
  private getStaff = this.getdata.appconstant + 'getStaff';
  private addStaff = this.getdata.appconstant + 'addStaff';
  private removeBulkStaffs = this.getdata.appconstant + 'removeBulkStaffs';
  private changePassword = this.getdata.appconstant + 'changePassword';
  private deleteStaff = this.getdata.appconstant + 'deleteStaff';
  private removeProduct = this.getdata.appconstant + 'removeProduct';

  getproductresponsedata: any;
  getstaffresponsedata: any;
  additemform: FormGroup;
  edititemform: FormGroup;
  producttype: any;
  productid: any;
  hsn: any = "HSN";
  itemname: any = "Item"
  numberpattern = /^[0-9]+$/;
  getcheckboxadditem = [];
  msg: any;

  /** Add Employee */
  addemployeeForm: FormGroup;
  changepassform: FormGroup;
  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;

  /** Get Data */
  isItemData: any = 'false';
  isEmpData: any = 'false';

  decimalnumber = /^(0|[1-9]\d*)(\.\d+)?$/;
  emailvalidation = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+")){2,}@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  numbervalidation = /^[0-9,/]+$/;
  alphanumeric = /^[a-zA-Z0-9]+$/;
  alphawithdot = /^[a-zA-Z. ]+$/;
  alpha = /^[a-zA-Z]+$/;
  passwordvalidation = /^(?=.*[A-Za-z])(?=.*\d)(?=.*[$@$!%*#?&])[A-Za-z\d$@$!%*#?&]{8,}$/;

  p: number = 1;
  itemsPerPage: number = 8;


  pemp: number = 1;
  itemsPerPageemp: number = 8;
  constructor(private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {

    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
  }

  ngOnInit() {
    this.additemreactiveform()
    this.edititemreactiveform()
    this.getproducts();
    this.getstaff();
    this.addempreactiveform();


    this.changepassform = this.Formbuilder.group({
      'password': [null, Validators.compose([Validators.required])],

    });
  }
  addempreactiveform() {

    this.addemployeeForm = this.Formbuilder.group({
      'name': [null, Validators.compose([Validators.required, Validators.pattern(this.alphawithdot)])],
      'email': [null, Validators.compose([Validators.required, Validators.pattern(this.emailvalidation)])],
      'password': [null, Validators.compose([Validators.required, Validators.pattern(this.passwordvalidation)])],
      'type': 'employee',
      'owner': this.userid
    });
  }
  showNotification(from, align, msg) {
    const type = ['success'];
    const color = Math.floor(1);
    $.notify({
      icon: 'notifications',
      message: msg

    }, {
        type: type[color],
        timer: 4000,
        placement: {
          from: from,
          align: align
        }
      });
  }

  additemreactiveform() {
    this.additemform = this.Formbuilder.group({
      'productname': [null, Validators.compose([Validators.required, Validators.maxLength(20), Validators.pattern(this.alphawithdot)])],
      'productprice': [null, Validators.compose([Validators.required, Validators.pattern(this.decimalnumber), Validators.maxLength(10)])],
      'producttype': ["goods", Validators.compose([Validators.required])],
      'gst': [null, Validators.compose([Validators.required])],
      'hsn': [null, Validators.compose([Validators.required, Validators.maxLength(8), Validators.pattern(this.numberpattern)])],

    });
  }

  edititemreactiveform() {
    this.edititemform = this.Formbuilder.group({
      'productname': [null, Validators.compose([Validators.required, Validators.maxLength(20), Validators.pattern(this.alphawithdot)])],
      'productprice': [null, Validators.compose([Validators.required, Validators.pattern(this.decimalnumber), Validators.maxLength(10)])],
      'producttype': [null, Validators.compose([Validators.required, Validators.pattern(this.numberpattern)])],
      'gst': [null, Validators.compose([Validators.required])],
    });
  }

  getproducts() {
    let fimaldata = "appcode=" + this.appcode;
    return this.makeapi.method(this.getProducts, fimaldata, "post")
      .subscribe(data => {
        if (data.length > 0) {
          this.isItemData = 'true';
        } else {
          this.isItemData = 'false';
        }
        this.getproductresponsedata = data;
        this.notificationsuccess("dfgd");
      },
        Error => {
          alert('get products error');
        });
  }

  getstaff() {
    let fimaldata = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getStaff, fimaldata, "post")
      .subscribe(data => {
        if (data.length > 0) {
          this.isEmpData = 'true';
        } else {
          this.isEmpData = 'false';
        }
        this.getstaffresponsedata = data;
        this.notificationsuccess("dfgd");
      },
        Error => {
          alert('get products error');
        });
  }

  getprodtype(prodtype) {
    if (prodtype == "service") {
      this.hsn = "SAC";
      this.itemname = "Service";
    }
    else {
      this.hsn = "HSN";
      this.itemname = "Item"
    }
  }

  edititem() {
    let fimaldata = "appcode=" + this.appcode + "&prodobj=" + JSON.stringify(this.edititemform.value) + "&prodid=" + this.productid;
    return this.makeapi.method(this.updateProduct, fimaldata, "post")

      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Product Added Successfully.', 'success');
          this.getproducts();
          $("#edititemmodal1").modal("hide");
          this.edititemreactiveform(); // this.notificationsuccess("stock added successfully")
        }
        else {
          // this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          this.getdata.showNotification('bottom', 'right', 'Product Details Already Exist', "danger");
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }
  additem() {
    this.additemform.value.gst = Number(this.additemform.value.gst);
    let fimaldata = "appcode=" + this.appcode + "&prodobj=" + JSON.stringify(this.additemform.value);
    return this.makeapi.method(this.addProduct, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Product Added Successfully.', 'success');
          this.getproducts();
          $("#additem").modal("hide");
          this.additemreactiveform(); // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      },
        Error => {
          // alert( 'add stock error' );
        });
  }
  seteditmodaldata(i) {
    this.producttype = this.getproductresponsedata[i].producttype;
    this.productid = this.getproductresponsedata[i]._id;
    this.edititemform = this.Formbuilder.group({
      'productname': [this.getproductresponsedata[i].productname, Validators.compose([Validators.required, Validators.maxLength(20), Validators.pattern(this.alphawithdot)])],
      'productprice': [this.getproductresponsedata[i].productprice, Validators.compose([Validators.required, Validators.pattern(this.decimalnumber), Validators.maxLength(10)])],
      'producttype': [this.getproductresponsedata[i].producttype, Validators.compose([Validators.required])],
      'gst': [this.getproductresponsedata[i].gst, Validators.compose([Validators.required])],
    });

    $("#edititemmodal1").modal("show");
  }
  notificationsuccess(text) {
    // notes.show(text, {
    //   type: 'success',
    //   // title: 'Hello',
    //   icon: '<i class="icon-tick-outline"></i>'
    // });

  }
  notificationdanger(text) {
    // notes.show(text, {
    //   type: 'danger',
    //   // title: 'Hello',
    //   icon: '<i class="icon-tick-outline"></i>'
    // });

  }

  getadditemcheckbox() {
    var getcheckboxadditem = $('.additemclass:checked').map(function () {
      return $(this).val();
    }).get();
    this.getcheckboxadditem = getcheckboxadditem;
    // console.log(this.getcheckboxadditem);
  }

  getallitemcheckbox(ischecked) {
    if (ischecked == true) {
      $('.additemclass:checkbox').prop('checked', true);
      var getcheckboxadditem = $('.additemclass:checked').map(function () {
        return $(this).val();
      }).get();
      this.getcheckboxadditem = getcheckboxadditem;
    }
    else {
      $('.additemclass:checkbox').prop('checked', false);
      this.getcheckboxadditem = [];
    }

  }

  getoverallempcheckbox(ischecked) {
    if (ischecked == true) {
      $('.employeeclass:checkbox').prop('checked', true);
      var getcheckboxemp = $('.employeeclass:checked').map(function () {
        return $(this).val();
      }).get();
      this.getcheckboxemp = getcheckboxemp;
    }
    else {
      $('.employeeclass:checkbox').prop('checked', false);
      this.getcheckboxemp = [];
    }



    // var getcheckboxempitem = $('.employeeclass:checked').map(function () {
    //   return $(this).val();
    // }).get();
    // this.getcheckboxemp = getcheckboxempitem;
    // console.log(  this.getcheckboxemp);
  }

  deleteitem() {
    let fimaldata = "appcode=" + this.appcode + "&prodid=" + JSON.stringify(this.getcheckboxadditem);
    return this.makeapi.method(this.removeBulkProducts, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Product Deleted Successfully.', 'success');
          this.getproducts();
          $("#deleteitemconfirmation").modal("hide");
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }

  deletebutton() {
    if (this.getcheckboxadditem.length < 1) {
      this.getdata.showNotification('bottom', 'right', 'select Item(s)', "danger");
    }
    else {
      $("#deleteitemconfirmation").modal("show");
    }
  }

  /*** Add Employee */
  addemployeeModal() {
    $("#addemployeeModal").modal("show");
  }

  addemployee() {
    var signupUser = this.addemployeeForm.value;
    var appcode = this.appcode;
    var datatype = "signupUser=" + JSON.stringify(signupUser) + "&appcode=" + appcode;
    return this.makeapi.method(this.addStaff, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            this.getdata.showNotification('bottom', 'right', 'Employee Added Successfully', "success");
            $("#addemployeeModal").modal("hide");
            this.getstaff();
          }
          else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {

        }
      );
  }
  getcheckboxemp: any = [];
  getempcheckbox() {
    var getcheckboxempitem = $('.employeeclass:checked').map(function () {
      return $(this).val();
    }).get();
    this.getcheckboxemp = getcheckboxempitem;
    // console.log(  this.getcheckboxemp);
  }
  deleteempbutton() {
    if (this.getcheckboxemp.length < 1) {
      this.getdata.showNotification('bottom', 'right', 'select Employee(s)', "danger");
    }
    else {
      $("#deleteempconfirmation").modal("show");
    }

  }

  deleteemployee() {
    let fimaldata = "appcode=" + this.appcode + "&employeeid=" + JSON.stringify(this.getcheckboxemp);
    return this.makeapi.method(this.removeBulkStaffs, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Employee(s) Deleted Successfully.', 'success');
          this.getstaff();
          this.getcheckboxemp = [];
          $("#deleteempconfirmation").modal("hide");
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }
  changepass(empid, pass) {
    if (!this.passwordvalidation.test(pass)) {
      this.getdata.showNotification('bottom', 'right', 'Minimum eight characters, at least one letter, one number and one special character', 'danger');
      return false;
    }
    let fimaldata = "appcode=" + this.appcode + "&empid=" + empid + "&password=" + pass;
    return this.makeapi.method(this.changePassword, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Password Changed Successfully.', 'success');
          this.getstaff();
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }

  searchtable(inputid, tableid) {
    // Declare variables 
    var input, filter, table, tr, td, i;
    input = document.getElementById(inputid);
    filter = input.value.toUpperCase();
    table = document.getElementById(tableid);
    tr = table.getElementsByTagName("tr");

    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1];
      if (td) {
        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }
  deleteid: any;
  setdeleteid(index) {
    this.deleteid = this.getproductresponsedata[index]._id;
  }
  deleteitemsingle() {
    let fimaldata = "appcode=" + this.appcode + "&prodid=" + this.deleteid;
    return this.makeapi.method(this.removeProduct, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Item Deleted Successfully.', 'success');
          this.getproducts();
          $("#deleteitem").modal("hide");
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }
  deleteempid: any;
  setdeleteempid(index) {
    this.deleteempid = this.getstaffresponsedata[index].userid;
  }
  deleteempsingle() {
    let fimaldata = "appcode=" + this.appcode + "&userid=" + this.deleteempid;
    return this.makeapi.method(this.deleteStaff, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Employee Deleted Successfully.', 'success');
          this.getstaff();
          $("#deleteemp").modal("hide");
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }

      },
        Error => {
          // alert( 'add stock error' );
        });
  }

  numbervalidationNextkey() {
    var getdata = this.additemform.value;
    getdata.hsn = getdata.hsn.replace(/[^0-9]/g, '');
    this.additemform.patchValue(getdata);
  }

}
