import { NgModule } from '@angular/core';
import { routing } from "./items.routing";
import { ChartModule } from 'angular-highcharts';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { ItemsComponent } from './items.component';
import { NgxPaginationModule } from 'ngx-pagination'; // <-- import the module
import { TooltipModule } from 'ngx-bootstrap/tooltip';

@NgModule({
    imports: [routing, ChartModule, CommonModule, ReactiveFormsModule, NgxPaginationModule, TooltipModule.forRoot()],
    declarations: [ItemsComponent]
})
export class ItemsModule { }