import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewestimatesComponent } from './viewestimates.component';

describe('ViewestimatesComponent', () => {
  let component: ViewestimatesComponent;
  let fixture: ComponentFixture<ViewestimatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ViewestimatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewestimatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
