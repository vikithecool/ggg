import { Component, OnInit, Injectable, ViewChild } from '@angular/core';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Router } from '@angular/router';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { FormBuilder, FormGroup, Validators, FormArray, FormControl } from '@angular/forms';
import { AuthGuard } from '../canactivate.service';

declare var $;
@Component({
  selector: 'app-viewestimates',
  templateUrl: './viewestimates.component.html',
  styleUrls: ['./viewestimates.component.css']
})
export class ViewestimatesComponent implements OnInit {
  modaldata: any;
  viewestimates: any;
  estimateobj: any;
  modaldatadetails: any;

  myForm: FormGroup;
  makeinvoiceform: FormGroup;
  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;

  states: any;

  getCredentialsdata: any;
  getCustomerdata: any;

  p: number = 1;
  itemsPerPage: number = 8;

  /** Is data */
  isData: any = 'false';

  private getSellers = this.getdata.appconstant + 'getSellers';
  private getCustomer = this.getdata.appconstant + 'getCustomer';
  private updateEstimate = this.getdata.appconstant + 'updateEstimate';


  private getEstimates = this.getdata.appconstant + 'getEstimates';
  private deleteEstimate = this.getdata.appconstant + 'deleteEstimate';
  private makeInvoice = this.getdata.appconstant + 'makeInvoice';
  private deleteBulkEstimate = this.getdata.appconstant + 'deleteBulkEstimate';
  private sendEstimateMail = this.getdata.appconstant + 'sendEstimateMail';

  minDate: Date;

  constructor(private getsession: AuthGuard, private Formbuilder: FormBuilder, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {

    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
  }
  createItem(): FormGroup {
    return this.Formbuilder.group({
      productdetails: '',
      productid: '',
      producttype: '',
      hsn: '',
      description: '',
      price: '',
      discount: '',
      discounttype: '',
      quantity: '',
      total: '',
      cgst: "",
      sgst: "",
      igst: "",
    });
  }
  ngOnInit() {
    this.myForm = this.Formbuilder.group({
      sellerid: ['', [Validators.required]],
      sellerappcode: [this.appcode],
      userid: [this.userid],
      customeridfull: ['', [Validators.required]],
      customerid: ['', [Validators.required]],
      shippingaddress: ['', [Validators.required]],
      placeofsupply: ['', [Validators.required]],
      total: ['', [Validators.required]],
      amountdue: ['', [Validators.required]],
      customernotes: [''],
      terms: [''],
      discount: [''],
      amountpaid: [''],
      ibillaccount: [null],
      details: this.Formbuilder.array([this.createItem()])
    });
    this.makeinvoicereactiveform()

    this.states = [
      { text: 'Andhra Pradesh', value: 'Andhra Pradesh' },
      { text: 'Arunachal Pradesh', value: 'Arunachal Pradesh' },
      { text: 'Assam', value: 'Assam' },
      { text: 'Bihar', value: 'Bihar' },
      { text: 'Chandigarh', value: 'Chandigarh' },
      { text: 'Chhattisgarh', value: 'Chhattisgarh' },
      { text: 'Dadra and Nagar Haveli', value: 'Dadra and Nagar Havelis' },
      { text: 'Daman and Diu', value: 'Daman and Diu' },
      { text: 'Delhi', value: 'Delhi' },
      { text: 'Goa', value: 'Goa' },
      { text: 'Gujarat', value: 'Gujarat' },
      { text: 'Haryana', value: 'Haryana' },
      { text: 'Himachal Pradesh', value: 'Himachal Pradesh' },
      { text: 'Jammu and Kashmir', value: 'Jammu and Kashmir' },
      { text: 'Jharkhand', value: 'Jharkhand' },
      { text: 'Karnataka', value: 'Karnataka' },
      { text: 'Kerala', value: 'Kerala' },
      { text: 'Lakshadweep', value: 'Lakshadweep' },
      { text: 'Madhya Pradesh', value: 'Madhya Pradesh' },
      { text: 'Maharashtra', value: 'Maharashtra' },
      { text: 'Manipur', value: 'Manipur' },
      { text: 'Meghalaya', value: 'Meghalaya' },
      { text: 'Mizoram', value: 'Mizoram' },
      { text: 'Nagaland', value: 'Nagaland' },
      { text: 'Odisha', value: 'Odisha' },
      { text: 'Puducherry', value: 'Puducherry' },
      { text: 'Punjab', value: 'Punjab' },
      { text: 'Rajasthan', value: 'Rajasthan' },
      { text: 'Sikkim', value: 'Sikkim' },
      { text: 'Tamil Nadu', value: 'Tamil Nadu' },
      { text: 'Telangana', value: 'Telangana' },
      { text: 'Tripura', value: 'Tripura' },
      { text: 'Uttar Pradesh', value: 'Uttar Pradesh' },
      { text: 'Uttarakhand', value: 'Uttarakhand' },
      { text: 'West Bengal', value: 'West Bengal' },


    ];
    this.getestimates();
    this.getInvoiceFromData();
    this.getCustomerData();
    this.getProductData();
  }
  makeinvoicereactiveform() {
    this.makeinvoiceform = this.Formbuilder.group({
      duedate: [new Date(), [Validators.required]],
      raiseddate: [new Date(), [Validators.required]],

    });
  }

  /** Get Invoice From or Seller Date */
  getInvoiceFromData() {
    var datatype = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getSellers, datatype, 'post')
      .subscribe(
        data => {
          // console.log(data);
          this.getCredentialsdata = data;
        },
        Error => {

        }
      )
  }
  onChangeraisedate(event) {

    var duedate = this.makeinvoiceform.value.duedate;
    if (duedate < event) {
      var getdata = this.makeinvoiceform.value;
      this.minDate = event;
      getdata.duedate = new Date(event);
      getdata.raiseddate = new Date(event);
      this.makeinvoiceform.patchValue(getdata);
    } else if (duedate == event) {

    } else {
      this.minDate = new Date(event);
      this.minDate.setDate(this.minDate.getDate());
    }
  }
  showSelected
  getCustomerid
  getShippingName
  getShippingCity
  getShippingAddress
  getShippingState
  getShippingCountry
  getShippingzip
  /** Add New Customer */
  toaddrchanged(event) {
    if (event.target.value == 'addcustomer') {
      this.showSelected = false;
      $('#customerModal2').modal('show');
    } else {
      this.showSelected = true;
      var temp = event.target.value.split('|');
      this.getCustomerid = temp[1];
      this.getShippingAddress = temp[0];
      this.getShippingName = temp[2];
      this.getShippingCity = temp[3];
      this.getShippingState = temp[4];
      this.getShippingCountry = temp[5];
      this.getShippingzip = temp[6];
      if (temp[7] == "") {
        this.myForm.get('ibillaccount').disable();
      } else {
        this.myForm.get('ibillaccount').enable();
        var getdata = this.myForm.value;
        getdata.ibillaccount = true;
      }
      /** Pass cutomer id to hidden field */
      var getdata = this.myForm.value;
      getdata.customerid = this.getCustomerid;
      this.myForm.patchValue(getdata);
    }
  }
  /** Get customer Details */
  getCustomerData() {
    var useridobj = { "userid": this.userid }
    var datatype = "appcode=" + this.appcode + "&userid=" + JSON.stringify(useridobj);
    return this.makeapi.method(this.getCustomer, datatype, 'post')
      .subscribe(
        data => {
          this.getCustomerdata = data;
        },
        Error => {

        }
      )
  }
  private getProducts = this.getdata.appconstant + 'getProducts';
  getProductdata: any;

  /** Get Product Details */
  getProductData() {
    var datatype = "appcode=" + this.appcode;
    return this.makeapi.method(this.getProducts, datatype, 'post')
      .subscribe(
        data => {
          this.getProductdata = data;
        },
        Error => {

        }
      );
  }
  /** Add new row */
  addRow(): void {
    // let fg = this.FormBuilder.group(new this.createItem());
    // this.details.push(fg);	 
    var details = this.myForm.get('details') as FormArray;
    details.push(this.createItem());
  }
  /** Delete Row */
  deleteRow(rowNumber) {
    this.estimateobj.estimate.details.splice(rowNumber, 1);
    // this.details = this.raiseInvoiceForm.get('invoice.details') as FormArray;
    // this.details.removeAt(rowNumber);
    // this.calc();
  }
  getcheckboxestimatelist = [];
  getestimatelistcheckbox() {
    var getcheckboxadditem = $('.additemclass:checked').map(function () {
      return $(this).val();
    }).get();
    this.getcheckboxestimatelist = getcheckboxadditem;
  }
  get myFormdetails() { return <FormArray>this.myForm.get('details') as FormArray }

  estimatedetails: any;
  getestimates() {
    let fimaldata = "appcode=" + this.appcode + "&userid=" + this.userid;
    return this.makeapi.method(this.getEstimates, fimaldata, "post")
      .subscribe(data => {
        if (data.length > 0) {
          this.isData = 'true';
        } else {
          this.isData = 'false';
        }
        this.viewestimates = data;
      },
        Error => {
          alert('get products error');
        });
  }
  estimateid: any;

  setdeleteid(estimateid) {
    this.estimateid = estimateid
  }
  deleteestimate() {
    let fimaldata = "appcode=" + this.appcode + "&estimateid=" + this.estimateid;
    return this.makeapi.method(this.deleteEstimate, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Estimate Deleted Successfully', "success");
          $("#deleteinvoice").modal("hide");
          this.getestimates();

        }
        else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      },
        Error => {
          alert('delete estimates error');
        });
  }
  getallestimatecheckbox(ischecked) {
    if (ischecked == true) {
      $('.additemclass:checkbox').prop('checked', true);
      var getcheckboxadditem = $('.additemclass:checked').map(function () {
        return $(this).val();
      }).get();
      this.getcheckboxestimatelist = getcheckboxadditem;
    }
    else {
      $('.additemclass:checkbox').prop('checked', false);
      this.getcheckboxestimatelist = [];
    }

  }
  makeinvoice() {

    var duedate = this.makeinvoiceform.value.duedate;
    var currentdate = duedate.getDate();
    var currentmonth = duedate.getMonth() + 1; // January is 0!
    var month = currentmonth;
    var currentyear = duedate.getFullYear();
    var finaldate;
    var finalmonth;
    if (currentdate < 10) {
      finaldate = '0' + currentdate;
    }
    else {
      finaldate = currentdate;
    }
    if (currentmonth < 10) {
      finalmonth = '0' + currentmonth;
    }
    else {
      finalmonth = currentmonth
    }
    var getdata = this.makeinvoiceform.value;
    getdata.duedate = currentyear + "-" + finalmonth + "-" + finaldate;
    this.makeinvoiceform.patchValue(getdata);
    var raiseddate = this.makeinvoiceform.value.raiseddate;
    var currentdate = raiseddate.getDate();
    var currentmonth = raiseddate.getMonth() + 1; // January is 0!
    var month = currentmonth;
    var currentyear = raiseddate.getFullYear();
    var finaldate;
    var finalmonth;
    if (currentdate < 10) {
      finaldate = '0' + currentdate;
    }
    else {
      finaldate = currentdate;
    }
    if (currentmonth < 10) {
      finalmonth = '0' + currentmonth;
    }
    else {
      finalmonth = currentmonth
    }
    var getdata = this.makeinvoiceform.value;
    getdata.raiseddate = currentyear + "-" + finalmonth + "-" + finaldate;
    this.makeinvoiceform.patchValue(getdata);
    let fimaldata = "appcode=" + this.appcode + "&estimateid=" + this.estimateid + "&obj=" + JSON.stringify(this.makeinvoiceform.value);
    return this.makeapi.method(this.makeInvoice, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Estimate Generated Successfully', "success");
          $("#makeinvoice").modal("hide");
          this.getestimates();
          this.makeinvoicereactiveform();
        }
        else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      },
        Error => {
          alert('Make invoice error');
        });
  }
  setmodaldata(i) {
    this.createItem();
    var shippingaddress = this.viewestimates[i].estimatedetails.shippingaddress;
    var getdata = this.myForm.value;
    getdata.customerid = this.viewestimates[i].estimatedetails.customerid;
    getdata.sellerid = this.viewestimates[i].estimatedetails.sellerid;
    getdata.sellerappcode = this.viewestimates[i].estimatedetails.sellerappcode;
    getdata.placeofsupply = this.viewestimates[i].estimatedetails.placeofsupply;
    getdata.shippingaddress = this.viewestimates[i].estimatedetails.shippingaddress;
    getdata.total = this.viewestimates[i].estimatedetails.total;
    getdata.amountdue = this.viewestimates[i].estimatedetails.amountdue;
    getdata.customernotes = this.viewestimates[i].estimatedetails.customernotes;
    getdata.terms = this.viewestimates[i].estimatedetails.terms;
    getdata.discount = this.viewestimates[i].estimatedetails.discount;
    getdata.amountpaid = this.viewestimates[i].estimatedetails.amountpaid;

    getdata.customeridfull = this.viewestimates[i].customerdetails.address + "|" + this.viewestimates[i].customerdetails._id + "|" + this.viewestimates[i].customerdetails.customername + "|" + this.viewestimates[i].customerdetails.city + "|" + this.viewestimates[i].customerdetails.homestate + "|" + this.viewestimates[i].customerdetails.country + "|" + this.viewestimates[i].customerdetails.zip;
    this.myForm.patchValue(getdata);



    this.getShippingName = shippingaddress.split(",")[0];
    this.getShippingAddress = shippingaddress.split(",")[1];
    this.getShippingCity = shippingaddress.split(",")[2];
    this.getShippingState = shippingaddress.split(",")[3];
    this.getShippingzip = shippingaddress.split(",")[4];

    if (this.getProductdata.length > 0) {

    }
    let control = this.myForm.get('details') as FormArray;
    this.createItem();
    control.removeAt(0);
    this.viewestimates[i].estimatedetails.details.forEach(data => {

      control.push(this.Formbuilder.group({
        productdetails: data.productid + "|" + data.description + "|" + data.producttype,
        productid: data.productid,
        producttype: data.producttype,
        hsn: data.hsn,
        description: data.description,
        price: data.price,
        discount: data.discount,
        discounttype: data.discounttype,
        quantity: data.quantity,
        total: data.total,
        cgst: data.cgst,
        sgst: data.sgst,
        igst: data.igst,
      }))
      // console.log(data)
    })

  }
  setemailmodaldata(i) {
    this.modaldata = this.viewestimates[i];
    this.modaldatadetails = this.viewestimates[i].estimatedetails.details;
  }

  dynamic_shipping_addr(event) {
    var temp = event.target.value.split('|');
    var address = temp[0] + ', ' + temp[3] + ', ' + temp[4] + ', ' + temp[5] + ', ' + temp[6];
    var getdata = this.myForm.value;
    getdata.shippingaddress = address;
    this.myForm.patchValue(getdata);
  }
  /** Raise Invoice */
  editestimate() {
    // console.log(this.estimateform.value.estimateobj);
    var to_id = this.myForm.value.customeridfull; // Get customer id
    var to_id = to_id.split('|'); // Get customer id
    var customerid = to_id[1]; // Get customer id
    var appcode = this.appcode;
    var userid = this.userid;
    var sellerid = this.myForm.value.sellerid;
    var shippingaddress = this.myForm.value.shippingaddress;
    this.myForm.get('customeridfull').disable();
    var getcontrol = this.myForm.get('details').value;
    getcontrol.forEach(data => {
      // console.log(data);
      delete data.productdetails;
    });
    // var datatype = 'userid=' + userid + '&sellerid=' + sellerid + "&customerid=" + customerid + "&shippingaddress=" + shippingaddress + "&invoice=" + JSON.stringify( this.myForm.value) + "&appcode=" + appcode;
    var datatype = "estimateid=" + this.estimateid + "&estimateobj=" + JSON.stringify(this.myForm.value) + "&appcode=" + appcode;

    return this.makeapi.method(this.updateEstimate, datatype, 'post')
      .subscribe(
        data => {
          if (data.status == "success") {
            this.getdata.showNotification('bottom', 'right', 'Estimate Updated Successfully', "success");
            $("#editinvoice").modal("hide");
            this.myForm.get('customeridfull').enable();
            this.getestimates();
          } else {
            this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
          }
        },
        Error => {

        }
      );
  }
  isdetailsdiscount: any;
  isdiscount: any = true;;

  alldiscountchanged(e) {

    var arraylength = this.myForm.get('details').value.length;
    var details = this.myForm.get('details').value;

    if (e.target.checked == true) {

      for (var i = 0; i < arraylength; i++) {
        details[i].discount = 0
        this.myForm.get('details').patchValue(details);
        this.isdetailsdiscount = true;
        this.isdiscount = false;
        this.onChanges(i)
      }
    }
    else {
      this.myForm.get('discount').patchValue('0');
      this.isdetailsdiscount = false;
      this.isdiscount = true;
      for (var i = 0; i < arraylength.length; i++) {

        this.onChanges(i)

      }
    }

  }
  /** Change Row data on change */
  private getSingleProduct = this.getdata.appconstant + 'getProduct';
  check_place: any;
  onChanges(index): void {
    // this.checkstate();
    var getdata = this.myForm.get('details').value;
    var row_description = getdata[index].productdetails;
    var row_quantity = getdata[index].quantity;
    var row_discount = getdata[index].discount;
    var tmp = row_description.split('|');
    var product_id = tmp[0];
    getdata[index].description = tmp[1];
    getdata[index].productid = tmp[0];
    var datatype = "appcode=" + this.appcode + "&prodid=" + product_id;
    this.makeapi.method(this.getSingleProduct, datatype, 'post')
      .subscribe(
        data => {
          getdata[index].price = data.productprice;
          getdata[index].hsn = data.hsn;
          if (this.check_place == 'true') {
            getdata[index].cgst = data.cgst;
            getdata[index].sgst = data.sgst;
            getdata[index].igst = 0;
          } else if (this.check_place == 'false') {
            getdata[index].cgst = 0;
            getdata[index].sgst = 0;
            getdata[index].igst = data.igst;
          } else {
            getdata[index].cgst = data.cgst;
            getdata[index].sgst = data.sgst;
            getdata[index].igst = data.igst;
          }

          /** Get row Total */
          getdata[index].total = data.productprice * row_quantity;

          // if ((row_discount == '') && (row_discount == 0)) {
          //   console.log("row_total: " + this.estimateobj.estimate.details[index].total)
          // } else {
          //   var getamt = data.productprice * row_quantity;
          //   this.estimateobj.estimate.details[index].total = getamt - (getamt * row_discount / 100);
          //   console.log("row_total: " + this.estimateobj.estimate.details[index].total)
          // }
          // console.log("row_total: " + this.details[index].total)

          /** Get Discout price */
          getdata[index].discount = row_discount;
          this.myForm.get('details').patchValue(getdata);
          this.calc();
        },
        Error => {
          console.log("Errow While Processing Changing product name");
        }
      )
  }
  // Calclutaion Area
  total_amt: number
  total_amt_wt: number
  calc() {
    var details = this.myForm.get('details').value;
    var getdata = this.myForm.value;
    var totaldiscount = getdata.discount;
    var amountpaid = getdata.amountpaid;
    var totallength = details.length;
    var total_amt = 0;
    var total_amt_wt = 0;
    getdata.total = 0;
    for (var j = 0; j < totallength; j++) {
      /** Tax Calculation */
      var discounted_amt = details[j].total - ((details[j].discount / 100) * details[j].total);
      getdata.total += ((((Number(details[j].cgst) + Number(details[j].sgst) + Number(details[j].igst)) / 100) * discounted_amt) + discounted_amt);  // Amount with Tax
      // total_amt += details[j].total; //Amount without tax
    }
    if (totaldiscount > 0) {
      getdata.amountdue = (getdata.total - (getdata.total * (totaldiscount / 100))) - amountpaid;
    } else {
      getdata.amountdue = getdata.total - amountpaid;
    }
    this.myForm.get('details').patchValue(details);
    this.myForm.patchValue(getdata);
  }
  /** Check State */
  checkstate() {
    var customer_id = this.myForm.value.customeridfull;
    // console.log(customer_id);
    if (customer_id != null) {
      var customer_split = customer_id.split("|");
      // console.log(customer_split);
      var customer_state = customer_split[4];
      var check_placeofsupply = this.myForm.value.placeofsupply;
      if (customer_state == check_placeofsupply) {
        this.check_place = 'true';
        // console.log("check_place: " + this.check_place);
        var valuelen = this.myForm.get('details').value.length;
        // console.log("valuelen: " + valuelen);
        for (var i = 0; i < valuelen; i++) {
          this.onChanges(i);
        }
      } else {
        this.check_place = 'false';
        valuelen = this.myForm.get('details').value.length;
        // console.log("valuelen: " + valuelen);
        for (var i = 0; i < valuelen; i++) {
          this.onChanges(i);
        }
      }
    } else {
      this.check_place = '';
      // console.log("check_place: " + this.check_place);
    }
  }

  deletebulkestimate() {
    let fimaldata = "appcode=" + this.appcode + "&estimateid=" + JSON.stringify(this.getcheckboxestimatelist);
    return this.makeapi.method(this.deleteBulkEstimate, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Estimates Deleted Successfully.', 'success');
          this.getestimates();
          $("#deleteconfirmation1").modal("hide");
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }

      },
        Error => {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        });
  }
  deletebutton() {
    if (this.getcheckboxestimatelist.length < 1) {
      this.getdata.showNotification('bottom', 'right', 'select Estimates(s)', "danger");
    }
    else {
      $("#deleteconfirmation1").modal("show");
    }
  }
  sendmail() {
    let fimaldata = "appcode=" + this.appcode + "&estimateid=" + this.estimateid;
    return this.makeapi.method(this.sendEstimateMail, fimaldata, "post")
      .subscribe(data => {
        if (data.status == "success") {
          this.getdata.showNotification('bottom', 'right', 'Email Sent Successfully.', 'success');
          // this.getestimates();
          $("#sendmailmodal").modal("hide");
          // this.notificationsuccess("stock added successfully")
        } else {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        }
      },
        Error => {
          this.getdata.showNotification('bottom', 'right', 'Something went wrong. Try again later', "danger");
        });
  }

  searchtable(inputid, tableid) {
    // Declare variables 
    var input, filter, table, tr, td, i;
    input = document.getElementById(inputid);
    filter = input.value.toUpperCase();
    table = document.getElementById(tableid);
    tr = table.getElementsByTagName("tr");

    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1];
      if (td) {
        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  routerUrl() {
    this.router.navigate(['dashboard/estimate']);
  }

}
