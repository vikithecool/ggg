import { NgModule  } from '@angular/core';
import { routing } from "./viewestimates.routing";
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { NgSelectModule } from '@ng-select/ng-select';
import { AbstractControl } from '@angular/forms';
import { ViewestimatesComponent } from './viewestimates.component';
import { BsDatepickerModule } from 'ngx-bootstrap';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@NgModule({
  imports: [routing,FormsModule,ReactiveFormsModule,CommonModule,NgSelectModule, BsDatepickerModule, NgxPaginationModule],
  declarations: [ViewestimatesComponent],
})
export class ViewestimateModule {}