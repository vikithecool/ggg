import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewestimatesComponent } from './viewestimates.component';


const routes: Routes = [
  { path: '', component: ViewestimatesComponent }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);