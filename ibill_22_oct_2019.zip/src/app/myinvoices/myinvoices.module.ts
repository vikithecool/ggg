import { NgModule } from '@angular/core';
import { routing } from "./myinvoices.routing";
import { ChartModule } from 'angular-highcharts';
import { MyinvoicesComponent } from './myinvoices.component';
import { CommonModule } from '@angular/common';
import {NgxPaginationModule} from 'ngx-pagination'; // <-- import the module

@NgModule({
  imports: [routing,ChartModule,CommonModule, NgxPaginationModule],
  declarations: [MyinvoicesComponent]
})
export class MyinvoicesModule {}