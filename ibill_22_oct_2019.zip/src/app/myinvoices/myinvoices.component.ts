import { Component, OnInit, Pipe, PipeTransform } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import { Subject } from 'rxjs/Subject';
import 'rxjs/add/operator/map';
import { WebserviceService } from '../webservice.service';
import { DatatransferService } from '../datatransfer.service';
import { Subscription } from 'rxjs/Subscription';
import { Chart } from 'angular-highcharts';
import { AuthGuard } from '../canactivate.service';
declare var $: any;
@Component({
  selector: 'app-myinvoices',
  templateUrl: './myinvoices.component.html',
  styleUrls: ['./myinvoices.component.css']
})
export class MyinvoicesComponent implements OnInit {
  singleinvoicedetails: any;
  myinvoicedata: any;
  generateMyInvoice: any;
  /** session       */
  appcode: any;
  userid: any;
  logintype: any;
  user_email: any;

  /** Is data */
  isData: any = 'false';

  p: number = 1;
  itemsPerPage: number = 8;
  private getMyInvoice = this.getdata.appconstant + 'getMyInvoice';

  constructor(private getsession: AuthGuard, private router: Router, private makeapi: WebserviceService, private getdata: DatatransferService, private http: Http) {

    //   this.selectedproductname = "Select product to view transactions"
    this.appcode = this.getsession.session().appcode;
    this.userid = this.getsession.session().id;
    this.logintype = this.getsession.session().type;
    this.user_email = this.getsession.session().email;
    this.logintype = this.getsession.session().type;
  }
  ngAfterViewInit() {

  }

  restrictminus(e) {
    if (!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58)
      || e.keyCode == 8)) {
      return false;
    }
  }
  restrictmaxlength(e, max) {
    if (!((e.keyCode > 95 && e.keyCode < 106)
      || (e.keyCode > 47 && e.keyCode < 58)
      || e.keyCode == 8)) {
      return false;
    }
    if (e.target.value.length == max && e.keyCode > 47 && e.keyCode < 58)
      return false;
  }
  ngOnInit() {

    this.getmyinvoice();

  }

  getmyinvoice() {
    let fimaldata = "appcode=" + this.appcode;
    return this.makeapi.method(this.getMyInvoice, fimaldata, "post")

      .subscribe(data => {
        if (data.length > 0) {
          this.isData = 'true';
        } else {
          this.isData = 'false';
        }
        this.myinvoicedata = data;
      },
        Error => {
          alert('get invoice error');
        });
  }
  setInvoicedetails(invid) {
    this.generateMyInvoice = this.getdata.appconstant + 'generateMyInvoice?appcode=' + this.appcode + '&invoiceid=' + invid + '&userid=' + this.userid + '&embedded=true';
    $('#printf').attr('src', this.generateMyInvoice);
  }

  printinv() {
    // window.open( 'http://172.30.1.2:8080/iBill/generateMyInvoice?appcode=' +  this.singleinvoicedetails.raisedby.appcode + '&invoiceid=' +  this.singleinvoicedetails.originalinvoiceid + '&userid=' +  this.singleinvoicedetails.raisedby.userid );
    //        window.open( 'https://sevael.in:8443/iBill/generateInvoice?appcode=' +  this.singleinvoicedetails.raisedby.appcode + '&invoiceid=' +  this.singleinvoicedetails.originalinvoiceid + '&userid=' +  this.singleinvoicedetails.raisedby.userid );
    var mywindow = window.frames["printf"];
    //        $('#printf').attr('src','http://172.30.1.2:8080/iBill/generateMyInvoice?appcode=' +  this.singleinvoicedetails.raisedby.appcode + '&invoiceid=' +  this.singleinvoicedetails.originalinvoiceid + '&userid=' +  this.singleinvoicedetails.raisedby.userid +'&embedded=true');

    $(mywindow.document).ready(function () {
      mywindow.print();
      setTimeout(function () {
        $('iframe#printf').remove();
      },
        2000);  // The iFrame is removed 2 seconds after print() is executed, which is enough for me, but you can play around with the value
    });


    return true;
  }

  searchgenerictable(inputval) {
    var value = inputval.toLowerCase();
    $("table tr").each(function (index) {
      if (index !== 0) {
        var $row = $(this);

        $row.find('td').each(function () {
          var id = $(this).text().toLowerCase();
          if (id.indexOf(value) !== 0) {
            $row.hide();
          }
          else {
            $row.show();
            return false;
          }
        });

      }
    });
  }


  searchtable(inputid, tableid) {
    // Declare variables 
    var input, filter, table, tr, td, i;
    input = document.getElementById(inputid);
    filter = input.value.toUpperCase();
    table = document.getElementById(tableid);
    tr = table.getElementsByTagName("tr");

    // Loop through all table rows, and hide those who don't match the search query
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1];
      if (td) {
        if (td.innerHTML.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  routerUrl() {
    this.router.navigate(['dashboard/invoice']);
  }
}
