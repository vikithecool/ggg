import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MyinvoicesComponent } from './myinvoices.component';



const routes: Routes = [
  { path: '', component: MyinvoicesComponent }
];

export const routing: ModuleWithProviders = RouterModule.forChild(routes);